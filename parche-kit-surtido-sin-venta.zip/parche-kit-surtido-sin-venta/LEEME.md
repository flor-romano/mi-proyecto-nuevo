# Parche para `kit-base` — hallazgos de "Surtido sin venta"

Paquete de relay del curso **Surtido sin venta** (Área Salón · COTO) al
chat donde vive `kit-base`. Sale de once vueltas de construcción y
correcciones de cliente.

**Qué es esto:** los 27 hallazgos que el curso encontró en el kit, cada
uno con síntoma, diagnóstico contra el código real del kit, cómo se
verificó y una propuesta concreta — más el código del curso donde está
el parche local que hoy funciona en producción.

**Qué NO es:** un diff aplicable. El kit no se editó desde el chat del
curso, por regla (CLAUDE.md §0.1: *"desde ese chat NO se edita nunca
`kit-base/`, ni para un arreglo de una línea; si algo del kit está mal
o falta, se anota y se relaya; lo canónico se edita en su propio
chat"*). Lo que hay acá es la anotación, completa y con evidencia,
para que el arreglo canónico se escriba de este lado.


## Cómo usarlo

1. Empezá por `hallazgos/00-INDICE.md`: están agrupados por si son bugs
   reproducidos, propuestas de herramienta o convenciones nuevas del
   cliente. **No todos son bugs y está marcado cuál es cuál.**
2. Cada `hallazgos/K##-*.md` es autocontenido y cierra con **dónde está
   el parche local** en `codigo-del-curso/`, con archivo y línea.
3. `diff-contra-el-kit/` muestra exactamente qué archivos del kit tocó
   el curso. Son dos, y conviene leer la nota de abajo antes de mirarlos.
4. `bitacora/README-CURSO.md` es la bitácora completa (2672 líneas) por si
   hace falta el contexto de una vuelta entera.


## El estado del kit después de este curso

Esto es lo más importante del paquete y conviene leerlo antes que nada:

**Ni un solo archivo CSS o JS del kit fue modificado.** Los 27 hallazgos
se resolvieron del lado del curso, con CSS y JS propios que cargan
después. El kit salió de este curso igual que entró.

Los dos archivos que figuran como modificados en `diff-contra-el-kit/`
son:

- **`js/curso.js`** — no es un archivo del kit en el sentido de los
  otros: el kit lo entrega como *boilerplate* y cada curso lo reescribe
  entero. El diff es grande porque es el curso, no un parche. Está en el
  paquete porque ahí viven casi todos los rodeos locales.
- **`tools/tests/video-fondo.mjs`** — **ésta sí es la única divergencia
  real respecto de un archivo del kit**, y son 20 líneas: un opt-out
  (`data-sin-poster`) que aplica a UN solo chequeo de los seis. Está
  marcada como divergencia dentro del propio archivo y es el hallazgo
  **K26**.

Y hay dos herramientas que el curso tuvo que inventar porque el kit no
las tenía. Van como candidatas a absorber, no como parches:

- **`tools/verify-places.mjs`** — el kit dibuja los `[data-hit]` pero no
  los `[data-place]` (hallazgo **K2**).
- **`tools/tests/puntaje-curso.mjs`** — `puntaje-maximo.mjs` no puede
  medir un curso con mini juego (hallazgo **K5**).


## Un aviso sobre el zip que estás leyendo

Este paquete **no** se armó con `tools/build-zip.py`, que es la
herramienta del kit, sino con tres líneas de `zipfile`. El motivo es el
hallazgo **K27**: `build-zip.py` le mete a todo zip que arma un
*mismatch* del flag UTF-8 entre el header local y el directorio
central, y `unzip` lo reporta como *"At least one warning-error was
detected"* — un descompresor que trate eso como error va a decir que el
archivo está dañado. No lo está (todo descomprime, el CRC da), pero se
ve mal, y le llega al cliente en cada entrega. Está medido en K27, con
la tabla de los cuatro casos.


## Una trampa de numeración, para no perder tiempo

El kit tiene su propia lista de hallazgos en **CLAUDE.md §7.18**, también
numerada K1, K2, K3… **No son los mismos.** En el código del curso, una
referencia escrita `§7.18 K10` es del kit; una escrita `K10` a secas es
de esta lista. Los archivos de `hallazgos/` solo usan esta numeración.


## Qué se midió, por si sirve de contexto

El curso es un SCO SCORM 1.2 de 13 diapositivas armado sobre kit-base
v1.9.80, con una suite de 19 tests en verde (dos de ellos escritos acá:
30 chequeos de reportes de cliente y 4 bloques de puntaje). El artboard
del PDF es 2520×1260 y todas las capturas están 1:1 con él.

Cada hallazgo se verificó midiendo contra el render, no a ojo: los
umbrales de medalla salen de un recorrido instrumentado, las hitboxes de
medir contra la imagen, y los dos hallazgos de la última vuelta (K25 y
K26) de grabar la transición cuadro a cuadro con `Page.screencast`.
