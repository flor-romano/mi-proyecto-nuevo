# Qué tocó el curso del kit

Generado comparando `kit-base/` contra `surtido-sin-venta/` archivo por
archivo, en `css/`, `js/` y `tools/`.

## Modificados (2)

- `js/curso.js`
- `tools/tests/video-fondo.mjs`

**`js/curso.js`** no es un parche: el kit lo entrega como boilerplate y
cada curso lo reescribe entero. El diff es grande porque es el curso.

**`tools/tests/video-fondo.mjs`** es la única divergencia real respecto
de un archivo del kit: 20 líneas, un opt-out (`data-sin-poster`) que
aplica a UN chequeo de los seis, marcado como divergencia dentro del
propio archivo. Es el hallazgo K26.

## Agregados por el curso (6)

- `css/assets.css`
- `css/diapositivas.css`
- `css/pulido.css`
- `tools/tests/puntaje-curso.mjs`
- `tools/tests/reporte-cliente.mjs`
- `tools/verify-places.mjs`

De ésos, `tools/verify-places.mjs` (K2) y `tools/tests/puntaje-curso.mjs`
(K5) son **candidatos a absorber en el kit**: no tienen nada de este
curso en particular. Los tres CSS y `tools/tests/reporte-cliente.mjs` sí
son propios del curso.

## Del kit que el curso no trae

Ninguno: el curso tiene los 0 archivos del kit completos.
