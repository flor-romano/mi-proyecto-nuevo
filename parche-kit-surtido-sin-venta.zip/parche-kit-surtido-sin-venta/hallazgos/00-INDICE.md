# Índice de hallazgos

27 hallazgos, de once vueltas de construcción y correcciones de cliente.
Agrupados por qué son: **no todos son bugs**, y el que no lo es está
marcado.

Formato de cada uno (§0.1 del proyecto): síntoma → diagnóstico contra el
código real → cómo se verificó → propuesta. Cada archivo cierra con
**dónde está el parche local** en `codigo-del-curso/`, con archivo y
línea, o dice que no hay porque el hallazgo no se puede resolver desde
un curso.

> Los K1–K14 se escribieron antes de que se fijara el apartado explícito
> "**Cómo se verificó**"; en ésos la verificación está dentro del
> diagnóstico, no como sección aparte.

### Probados contra el código del kit — 23

- **K1** · `.d-mj` no tiene alto propio, y el kit no dice quién se lo da  
  [`K01-d-mj-no-tiene-alto-propio-y-el-kit-no-dice-quien-se-lo-da.md`](K01-d-mj-no-tiene-alto-propio-y-el-kit-no-dice-quien-se-lo-da.md)
- **K2** · `verify-hitboxes.mjs` NO dibuja los `[data-place]`, y §7.3 punto 9 dice que sí  
  [`K02-verify-hitboxes-mjs-no-dibuja-los-data-place-y-7-3-punto-9.md`](K02-verify-hitboxes-mjs-no-dibuja-los-data-place-y-7-3-punto-9.md)
- **K3** · El pop-up "Cómo recorrer el curso" que genera el kit narra VACÍO  
  [`K03-el-pop-up-como-recorrer-el-curso-que-genera-el-kit-narra-v.md`](K03-el-pop-up-como-recorrer-el-curso-que-genera-el-kit-narra-v.md)
- **K4** · El glosario del boilerplate narra las pistas de candado, y pegadas  
  [`K04-el-glosario-del-boilerplate-narra-las-pistas-de-candado-y.md`](K04-el-glosario-del-boilerplate-narra-las-pistas-de-candado-y.md)
- **K5** · `puntaje-maximo.mjs` no puede medir un mini juego, y declarar el máximo obliga a mentir  
  [`K05-puntaje-maximo-mjs-no-puede-medir-un-mini-juego-y-declarar.md`](K05-puntaje-maximo-mjs-no-puede-medir-un-mini-juego-y-declarar.md)
- **K7** · Los flotantes de Ayuda/Configuración tapan contenido interactivo en pantallas bajas  
  [`K07-los-flotantes-de-ayuda-configuracion-tapan-contenido-inter.md`](K07-los-flotantes-de-ayuda-configuracion-tapan-contenido-inter.md)
- **K8** · Documentación que dice algo distinto del código  *(PROBADO, todo menor)*  
  [`K08-documentacion-que-dice-algo-distinto-del-codigo.md`](K08-documentacion-que-dice-algo-distinto-del-codigo.md)
- **K9** · `[data-narrate-only]` funciona en los pop-ups y no en las diapositivas  
  [`K09-data-narrate-only-funciona-en-los-pop-ups-y-no-en-las-diap.md`](K09-data-narrate-only-funciona-en-los-pop-ups-y-no-en-las-diap.md)
- **K10** · El motor de voz falso de `locucion-control.mjs` nunca se instala  
  [`K10-el-motor-de-voz-falso-de-locucion-control-mjs-nunca-se-ins.md`](K10-el-motor-de-voz-falso-de-locucion-control-mjs-nunca-se-ins.md)
- **K11** · `Logros.restore()` no valida contra el catálogo y `unlock()` sí  
  [`K11-logros-restore-no-valida-contra-el-catalogo-y-unlock-si.md`](K11-logros-restore-no-valida-contra-el-catalogo-y-unlock-si.md)
- **K12** · El ancla provisional de §7.18 K2 hace fallar a `overlays-colocados`, de forma intermitente  
  [`K12-el-ancla-provisional-de-7-18-k2-hace-fallar-a-overlays-col.md`](K12-el-ancla-provisional-de-7-18-k2-hace-fallar-a-overlays-col.md)
- **K15** · El `.d-shot-hit-play` del kit no trae ícono, y su marcado de ejemplo tampoco  
  [`K15-el-d-shot-hit-play-del-kit-no-trae-icono-y-su-marcado-de-e.md`](K15-el-d-shot-hit-play-del-kit-no-trae-icono-y-su-marcado-de-e.md)
- **K16** · Ayuda y Configuración se abren con el mouse encima, y no hay forma de pedir "solo clic"  
  [`K16-ayuda-y-configuracion-se-abren-con-el-mouse-encima-y-no-ha.md`](K16-ayuda-y-configuracion-se-abren-con-el-mouse-encima-y-no-ha.md)
- **K17** · El kit dice "el máximo posible del curso" para cualquier puntaje por encima del último nivel  
  [`K17-el-kit-dice-el-maximo-posible-del-curso-para-cualquier-pun.md`](K17-el-kit-dice-el-maximo-posible-del-curso-para-cualquier-pun.md)
- **K18** · El kit sabe que este curso no puede usar el recorte de tablet, pero no da forma de apagarlo  
  [`K18-el-kit-sabe-que-este-curso-no-puede-usar-el-recorte-de-tab.md`](K18-el-kit-sabe-que-este-curso-no-puede-usar-el-recorte-de-tab.md)
- **K19** · `showPopup()` enfoca el primer campo de texto, y en iPadOS eso dispara el cartel de "estás escribiendo"  
  [`K19-showpopup-enfoca-el-primer-campo-de-texto-y-en-ipados-eso.md`](K19-showpopup-enfoca-el-primer-campo-de-texto-y-en-ipados-eso.md)
- **K21** · El kit escribe todo el chrome en `rem` pero nunca define el tamaño de raíz  
  [`K21-el-kit-escribe-todo-el-chrome-en-rem-pero-nunca-define-el.md`](K21-el-kit-escribe-todo-el-chrome-en-rem-pero-nunca-define-el.md)
- **K22** · `initBgVideos()` da por perdido cualquier error que no sea `NotAllowedError`  
  [`K22-initbgvideos-da-por-perdido-cualquier-error-que-no-sea-not.md`](K22-initbgvideos-da-por-perdido-cualquier-error-que-no-sea-not.md)
- **K23** · No hay forma de saber si el alumno eligió velocidad de locución  
  [`K23-no-hay-forma-de-saber-si-el-alumno-eligio-velocidad-de-loc.md`](K23-no-hay-forma-de-saber-si-el-alumno-eligio-velocidad-de-loc.md)
- **K24** · `initBgVideos()` no tiene `onFirstPlay` y `initInlineCircleVideos()` sí  
  [`K24-initbgvideos-no-tiene-onfirstplay-y-initinlinecirclevideos.md`](K24-initbgvideos-no-tiene-onfirstplay-y-initinlinecirclevideos.md)
- **K25** · Los overlays de una diapositiva no visitada llegan SIN medidas  
  [`K25-los-overlays-de-una-diapositiva-no-visitada-llegan-sin-med.md`](K25-los-overlays-de-una-diapositiva-no-visitada-llegan-sin-med.md)
- **K26** · `video-fondo.mjs` no prevé el "contenedor vacío"  
  [`K26-video-fondo-mjs-no-preve-el-contenedor-vacio.md`](K26-video-fondo-mjs-no-preve-el-contenedor-vacio.md)
- **K27** · `build-zip.py` rompe el flag UTF-8 que dice arreglar, y su propia verificación no lo ve  
  [`K27-build-zip-py-rompe-el-flag-utf-8-que-dice-arreglar-y-su-pr.md`](K27-build-zip-py-rompe-el-flag-utf-8-que-dice-arreglar-y-su-pr.md)

### Reproducido por síntoma (no se pudo instrumentar el dispositivo) — 1

- **K20** · El `fullscreen` de video en iOS/iPadOS no emite `fullscreenchange`, así que el reproductor vuelve mal ubicado  *(PROBADO por síntoma)*  
  [`K20-el-fullscreen-de-video-en-ios-ipados-no-emite-fullscreench.md`](K20-el-fullscreen-de-video-en-ios-ipados-no-emite-fullscreench.md)

### Probado en el curso, sospechado en el kit — 1

- **K6** · Los overlays del kit miden la tipografía en `cqw` del ESCENARIO, no del arte  *(PROBADO en el curso, SOSPECHADO en el kit)*  
  [`K06-los-overlays-del-kit-miden-la-tipografia-en-cqw-del-escena.md`](K06-los-overlays-del-kit-miden-la-tipografia-en-cqw-del-escena.md)

### Propuesta de herramienta (no es un bug) — 1

- **K13** · Nada avisa si un curso se entrega con el ícono placeholder  *(PROPUESTA, no bug)*  
  [`K13-nada-avisa-si-un-curso-se-entrega-con-el-icono-placeholder.md`](K13-nada-avisa-si-un-curso-se-entrega-con-el-icono-placeholder.md)

### Convención nueva del cliente (no es un bug) — 1

- **K14** · Tope de 5 logros por curso  *(CONVENCIÓN NUEVA del cliente, no bug)*  
  [`K14-tope-de-5-logros-por-curso.md`](K14-tope-de-5-logros-por-curso.md)

---

## Orden sugerido para atacarlos

Si hay que priorizar, éstos son los que más veces costaron una vuelta de
entrega o siguen obligando a cada curso a escribir el mismo rodeo:

1. **K27** — `build-zip.py` mete un warning de zip dañado en TODO
   paquete que arma el kit, y su propia verificación no lo puede ver.
   Es el más barato de arreglar (borrar un bucle) y el que le llega al
   cliente.
2. **K25** — los overlays de una diapositiva no visitada llegan sin
   medidas. Es el que el cliente reportó como "rebote", y lo arrastra
   cualquier curso con `[data-hit]`/`[data-place]`.
3. **K12** y **K2** — la misma familia: colocación de overlays, y
   herramientas para poder verla.
4. **K21** — el kit escribe todo el chrome en `rem` y nunca define la
   raíz, así que la interfaz no escala en ningún monitor grande.
5. **K22** y **K24** — el video de fondo: no reintenta ante nada que no
   sea `NotAllowedError`, y no tiene `onFirstPlay`.
6. **K5** — sin un test de puntaje que soporte mini juego, declarar el
   máximo obliga a escribir un número que no se puede medir.
