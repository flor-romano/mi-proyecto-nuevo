# K1 · `.d-mj` no tiene alto propio, y el kit no dice quién se lo da — PROBADO

- **Síntoma.** `hitbox-click-check` en rojo:
  `[minijuego] "¡Empecemos! Comenzar el mini juego": tamaño 0×0 (no
  inicializado o roto)`. En pantalla, la capa de portada del mini juego
  no dibujaba nada. Cero errores de consola.
- **Diagnóstico contra el código real.** `coto-minijuego.css` línea 35:
  `.d-mj{ flex:1 1 auto; min-height:0; width:100% }` y línea 53
  `.d-mj-panel{ height:100% }`. `.slide` (coto-shot-stage.css) es
  `display:flex; align-items:center`, así que el alto de `.d-mj` sale de
  su contenido: el `height:100%` del panel se resuelve contra `auto` y
  colapsa, y con él `.d-mj-shot` —que además tiene `container-type:size`,
  o sea contención en los dos ejes—. **Es exactamente el mecanismo que
  el kit ya corrigió un nivel más abajo en v1.9.61 (§7.09 punto 1)**,
  cuando le puso `height:100%` a `.d-mj-shot`: el contenedor de arriba
  quedó con la misma deuda.
- **Por qué es del kit y no de este curso.** Auditando el curso de
  referencia ("Seguridad alimentaria") aparece el mismo pegamento
  escrito a mano: `.slide-minijuego{display:flex}` en su `pulido.css` y
  `.slide-minijuego .slide-inner{flex:1 1 auto; width:100%; height:100%;
  display:flex; flex-direction:column}` en su `diapositivas.css`, con un
  comentario que explica por qué hacen falta los dos. Dos cursos, las
  mismas 5 líneas, redescubiertas por separado.
- **Verificación.** `hitbox-click-check` rojo → verde con
  `[data-slide="minijuego"]{align-items:stretch}` +
  `.d-mj{align-self:stretch; height:100%; min-height:0; display:flex;
  flex-direction:column}` (está en `css/diapositivas.css` de este curso,
  comentado como parche local).
- **Propuesta.** Que `coto-minijuego.css` se haga cargo —ya es dueño de
  `.d-mj`— o, si depende de cómo cada curso arme la diapositiva, una
  fila en `contrato-cableado` con la consecuencia escrita.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `css/diapositivas.css:320`
