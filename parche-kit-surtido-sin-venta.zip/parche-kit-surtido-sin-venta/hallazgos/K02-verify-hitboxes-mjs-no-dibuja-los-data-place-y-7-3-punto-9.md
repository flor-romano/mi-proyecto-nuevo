# K2 · `verify-hitboxes.mjs` NO dibuja los `[data-place]`, y §7.3 punto 9 dice que sí — PROBADO

- **Síntoma.** `npm run verify-hitboxes` informó
  `[consejos] 0 hitbox(es)` en una diapositiva que tiene 5 `[data-place]`
  encima del arte.
- **Diagnóstico.** `tools/verify-hitboxes.mjs` línea 145:
  `Array.from(shot.querySelectorAll('[data-hit]'))`. La cadena
  `data-place` no aparece en todo el archivo (`grep`). Mientras tanto
  §7.3 punto 9 dice, textual: *"El overlay de hitboxes también dibuja los
  `[data-place]`, y hay que mirarlos… Se ve corriendo
  `tools/verify-hitboxes.mjs` y mirando las capturas"*. La regla existe,
  la herramienta no la cumple, y es una regla sobre algo que **no rompe
  nada** (un `[data-place]` mal puesto solo se superpone al arte) — o
  sea, la única forma de verlo era justamente esa.
- **Verificación.** Se escribió `tools/verify-places.mjs` en este curso
  (herramienta local, no va al kit tal cual): dibuja los 9 `[data-place]`
  de este curso, revelando además las capas ocultas de a una. Con eso se
  confirmó la posición de las 5 píldoras de "Últimos consejos", los 4
  números de los paneles finales del mini juego y el párrafo del cierre.
- **Propuesta.** Una línea en `verify-hitboxes.mjs`
  (`'[data-hit], [data-place]'`, con otro color para distinguirlos, que
  es lo que §7.3 describe). Si se decide no hacerlo, corregir §7.3 punto
  9 — hoy manda a mirar algo que no se dibuja.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `tools/verify-places.mjs` — herramienta que el curso tuvo que inventar porque el kit no dibuja los [data-place]
