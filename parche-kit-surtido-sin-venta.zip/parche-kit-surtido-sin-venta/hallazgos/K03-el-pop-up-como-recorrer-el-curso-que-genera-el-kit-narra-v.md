# K3 · El pop-up "Cómo recorrer el curso" que genera el kit narra VACÍO — PROBADO

- **Síntoma.** `Narrador.textOf()` sobre
  `[data-popup="instrucciones"] .modal-card` devuelve **cadena vacía**.
  O sea: el primer pop-up que ve un alumno de CUALQUIER curso generado
  no se narra. `initPopupNarration()` corre, llama a `speak('')` y no
  pasa nada. Sin error.
- **Diagnóstico.** `narrador.js` línea 515:
  `TEXT_SEL = 'h2, p, dt, dd, li, .d-q-title, .d-opt-text, .d-quiz-fb,
  .d-quiz-result, .who, .d-cert-note, .d-instr-item'`. El modal que
  escribe `new-course.mjs` usa `<h3>` en `.d-instr-hd` y, en cada
  tarjeta, `.d-instr-card > div > b` + `span`. **Ninguno entra.**
  `.d-instr-item` —que sí está en la lista— es la clase de la grilla de
  tips de *Ayuda* (§6.54 punto 4), otra pieza: el rediseño v3 del
  instructivo (§6.10.2 / §6.20) cambió el marcado y `TEXT_SEL` nunca lo
  siguió.
- **Verificación.** Se volcó el `textOf()` de los 8 pop-ups del curso:
  el de instrucciones era el único vacío. Con
  `Narrador.addTextSel('.d-instr-modal h3, .d-instr-card > div > b,
  .d-instr-card > div > span')` (parche local, en `js/curso.js`) pasa a
  narrar *"Cómo recorrer el curso. Es interactivo. Mirá los videos…"*.
- **Propuesta.** Sumar `.d-instr-card b, .d-instr-card span` (y el `h3`
  del modal) a `TEXT_SEL` en `narrador.js`. Es del kit por definición:
  el marcado lo escribe el kit y el selector también.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `index.html:464` — el curso escribe su propio pop-up "Cómo recorrer el curso" en vez del que genera el kit
