# K4 · El glosario del boilerplate narra las pistas de candado, y pegadas — PROBADO

- **Síntoma.** `textOf()` del pop-up de glosario devolvía, por cada
  término: *"…No aparece en el envase.Se desbloquea al llegar a
  «Algunos conceptos importantes»."* — la pista del candado narrada
  aunque el término esté DESBLOQUEADO, y pegada al final de la
  definición sin espacio.
- **Diagnóstico.** Dos cosas que se suman:
  1. `coto-base-addendum-v1.8.css` líneas 837-838 esconden
     `.d-gloss-def`/`.d-gloss-hint` con `display:none`, y `textOf()`
     filtra por el **atributo** `hidden`, nunca por el display calculado.
     Es la trampa F1 que el propio §7.21 documenta — solo que acá la
     produce el marcado que recomienda el kit.
  2. Los dos `<span>` viven en el mismo `<dd>`, así que `textContent`
     los concatena sin separador.
  El addendum ya dice, en el encabezado de su §21, que *"la frase de
  entrada va con `[data-narrate-only]` para no narrar los 16 términos de
  corrido"* — pero `index-boilerplate.html` (lo que escribe
  `new-course.mjs`) **no emite ese párrafo**. La regla está y el marcado
  generado no la cumple.
- **Verificación.** Se volcó el `textOf()` del pop-up antes y después de
  agregar `<p class="d-glossary-intro" data-narrate-only>` al marcado:
  pasa de los 12 términos con sus 12 pistas a la sola frase de entrada.
- **Propuesta.** Que el boilerplate emita ese párrafo; y, aparte, que
  `initGlossaryUnlock()` marque `.d-gloss-hint`/`.d-gloss-def` con el
  atributo `hidden` además de la clase — así el glosario queda bien
  narrado incluso en un curso que decida narrarlo entero.


---

### Dónde está el parche local

No hay: este hallazgo no se puede resolver desde un curso. Es del kit.
