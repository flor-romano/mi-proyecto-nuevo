# K5 · `puntaje-maximo.mjs` no puede medir un mini juego, y declarar el máximo obliga a mentir — PROBADO

- **Síntoma.** Contra este curso, el test informa
  `puntaje medido: 74`, cuando el máximo real es **199**.
- **Diagnóstico.** Su recorrido toca
  `[data-hit], [data-shot-swap-step], [data-shot-swap-go],
  [data-popup-trigger], [data-layer-trigger], [data-repaso-ans]`. Las
  respuestas de un mini juego son `<button class="d-mj-opt">` que el
  curso fabrica con `innerHTML` — no están en esa lista. Y aunque
  estuvieran, tocarlas todas no sería "el máximo": las incorrectas
  cuestan vidas. O sea que no es un selector que falte, es que **un
  recorrido genérico no puede jugar un juego**.
- **La consecuencia incómoda.** `data-puntaje-max` es todo o nada: si
  este curso declara 199, el test falla; si declara 74, el test pasa
  afirmando algo falso. Este curso **no lo declara** —el test informa y
  no exige, que es el comportamiento documentado— y verifica su máximo
  en `tools/tests/puntaje-curso.mjs`, que sí juega el juego (perfecto,
  mínimo e "insistente").
- **Verificación.** Los dos tests conviven en la suite y dan verde: el
  del kit informando 74, el del curso midiendo 199 / 74 / 50.
- **Propuesta.** Un gancho opcional —del estilo
  `window.__PUNTAJE_RECORRIDO__()` que el curso implemente y el kit
  llame— para que `puntaje-maximo` pueda pedirle al curso que complete
  lo que el recorrido genérico no alcanza. Si no, dejar escrito en §7.3
  punto 19 que un curso con mini juego declara su máximo en un test
  propio.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `tools/tests/puntaje-curso.mjs` — test que el curso tuvo que inventar para medir un mini juego
