# K6 · Los overlays del kit miden la tipografía en `cqw` del ESCENARIO, no del arte — PROBADO en el curso, SOSPECHADO en el kit

- **Síntoma (en este curso, y está corregido acá).** En un teléfono
  acostado real (750×340, `openCourseMobile`, contexto táctil) el texto
  de las 5 píldoras de "Últimos consejos" **se derramaba fuera de la
  píldora**, blanco sobre blanco e ilegible.
- **Diagnóstico.** `.d-stage` es el contenedor de consulta
  (`container-type:size`), así que `1cqw` es el 1 % del ESCENARIO. Pero
  fuera del rango de proporción donde la captura llena el frame
  (`@container (min-aspect-ratio:1.5) and (max-aspect-ratio:2.2)`,
  coto-shot-stage.css), `.d-shot` queda letterboxeada y bastante más
  angosta. Medido en ese viewport: escenario 750 px de ancho, `.d-shot`
  **366 px** → `1cqw` vale más del doble que el 1 % del arte, y una
  tipografía dimensionada así sale al doble de tamaño.
- **Verificación / fix local.** Cada overlay pasa a ser su propio
  contenedor (`container-type:inline-size`) y la tipografía se mide
  contra ÉL: 5.2 % del ancho de la píldora, que es la proporción real
  medida sobre el arte. Con eso escala parejo en cualquier tamaño;
  verificado con capturas en 1600×900 y en 750×340 táctil.
- **Lo que es SOSPECHA y no está probado.** El kit dimensiona así sus
  propios overlays del panel final del mini juego
  (`.d-mj-fin-tit{font-size:clamp(1.1rem, 2.6cqw, 1.9rem)}`,
  `.d-mj-fin-stat b`, `.d-mj-fin-sub`, coto-minijuego.css). Esos viven
  dentro de `.d-mj-fin`, que es `container-type:size` — otro contenedor,
  con el mismo desfasaje potencial entre su ancho y el del `.d-shot` de
  adentro. **No lo reproduje**: en este curso los números finales son
  cortos y no llegaron a desbordar. Lo dejo anotado como algo para mirar
  con un texto largo, no como bug confirmado.
- **Propuesta.** Dejar la receta escrita (un overlay que lleva texto se
  declara `container-type:inline-size` y se dimensiona contra sí mismo)
  donde se la busque: §7.3, o el encabezado de `coto-shot-stage.css`
  junto a `.d-shot-hit`.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `css/diapositivas.css:50` — `container-type:inline-size` en la caja del overlay en vez de `cqw` del escenario
