# K7 · Los flotantes de Ayuda/Configuración tapan contenido interactivo en pantallas bajas — PROBADO

- **Síntoma.** En 750×340 táctil, los dos botones flotantes del kit
  tapaban la cuarta píldora de opción del mini juego ("Falso stock") y
  la tarjeta "Reglas".
- **Diagnóstico.** `.d-fab-stack{position:fixed; right:22px;
  bottom:80px; z-index:60}` (coto-player-chrome.css). En una
  diapositiva-captura eso solo tapa arte y no importa; en una
  diapositiva de layout HTML a todo el ancho, tapa controles. Y **ningún
  test lo ve**: `hitbox-click-check` solo mira `[data-hit]`, y estos
  botones no lo son.
- **Verificación.** Capturas antes/después en el mismo viewport táctil.
  Fix local: `padding-right` en `.d-mj-play` por debajo de 560 px de
  alto, reservando el ancho de la pila (52+22 px, 46+14 en mobile).
  No se movieron los flotantes: su posición es del kit y tiene que ser
  la misma en todo el curso.
- **Propuesta.** Una clase utilitaria del kit (o una regla con `:has()`)
  que reserve esa canaleta en diapositivas que no son captura.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `css/pulido.css:38` — bloque de los dos flotantes
