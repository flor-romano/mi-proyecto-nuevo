# K8 · Documentación que dice algo distinto del código — PROBADO, todo menor

Familia §6.69. Ninguno rompe nada; todos hacen dudar:

- `kit-base/PROMPT-CURSO-NUEVO.md` dice *"usando el kit adjunto
  (`kit-base/`, v1.9.71)"* — el kit es **1.9.80** (`README.md` línea 3 y
  `package.json`). Como ese prompt se copia tal cual a cada chat nuevo,
  el número viaja mal a todos lados. **De hecho el prompt con el que
  arrancó este curso decía "9/9 en verde"**, de una copia todavía más
  vieja; el kit real corre 17.
- `CLAUDE.md` §7 paso 1 dice *"los **16** tests de `tools/tests/`"*.
  Son **17** (`ls tools/tests/*.mjs | grep -v '/_' | wc -l`). Y lo
  llamativo: §7.26 —la sección de esta misma v1.9.80— dice que §7
  *"pasó a listar los 15 JS, 13 CSS y 16 tests reales"*. O sea que la
  ronda que fue a corregir el número lo dejó errado por uno (los 15 JS
  y los 13 CSS sí dan). Mientras tanto `PROMPT-CURSO-NUEVO.md` dice
  17/17, así que las dos cifras conviven en el mismo zip.
- La plantilla `js/curso.js` se presenta como *"kit-base v1.9.40"* y su
  checklist dice *"correr `tools/tests/*.mjs` (los **7**, exit 0 en
  todos)"*. Mismo texto en `kit-base/README.md`, paso 4 de "Arrancar un
  curso nuevo".
- `kit-base/README.md` describe `tools/tests/` como *"suite pass/fail
  genérica, **7 tests**"* y lista 12 archivos JS en el árbol cuando hay
  15.

Sugerencia de método, no de texto: los números que describen el contenido
del propio kit (cuántos tests, cuántos módulos, qué versión) son
exactamente la clase de afirmación que §6.60 dice que no se escribe a
mano — un chequeo de una línea en `npm run test:kit` que compare el
conteo real contra el documentado los mantendría sincronizados solos.


---

### Dónde está el parche local

No hay: este hallazgo no se puede resolver desde un curso. Es del kit.
