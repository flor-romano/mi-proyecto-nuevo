# K9 · `[data-narrate-only]` funciona en los pop-ups y no en las diapositivas — PROBADO

- **Síntoma.** El cliente pidió que la diapositiva de índice locutara
  solo su título y el nombre del curso, sin enumerar los 7 ítems del
  temario (que en pantalla están horneados en la captura, y en el DOM
  viven como `<ul class="sr-only">` porque son el único acceso que tiene
  un lector de pantalla a esa imagen). O sea: sacar algo de la VOZ sin
  sacarlo de la accesibilidad.
- **Diagnóstico.** El kit ya tiene exactamente esa convención:
  `initPopupNarration()` (coto-ui.js) hace
  `pop.querySelector('[data-narrate-only]') || pop.querySelector('.modal-card')`
  y narra solo ese nodo. Pero la narración de DIAPOSITIVA no pasa por
  ahí: `initPlayer()` recibe `speakSlide` y el curso le pasa la
  `<section>` entera a `Narrador.textOf()`. La convención existe, está
  documentada, y del lado de las diapositivas no la mira nadie.
  Los otros dos atributos de la familia (`[data-narrate-last]`,
  `[data-narrate-prefix]`) sí viven dentro de `textOf()` y por eso
  funcionan en los dos lados; `[data-narrate-only]` quedó del lado de
  quien llama.
- **Verificación.** Con `speakSlide` mirando primero
  `s.querySelector('[data-narrate-only]')`, el índice pasa de locutar el
  temario completo a decir exactamente *"Índice de contenidos. Control
  de surtido sin venta."*, y la lista sigue intacta en el DOM (7 `<li>`,
  chequeado en `tools/tests/reporte-cliente.mjs`).
- **Propuesta.** Que la plantilla `js/curso.js` traiga ese
  `querySelector` en su `speakSlide` —son dos líneas y es el lugar donde
  cada curso lo copia—, o que `textOf()` respete el atributo desde
  adentro, como ya hace con los otros dos.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:356`
