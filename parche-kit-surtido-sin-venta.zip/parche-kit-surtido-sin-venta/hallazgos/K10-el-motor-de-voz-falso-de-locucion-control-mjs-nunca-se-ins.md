# K10 · El motor de voz falso de `locucion-control.mjs` nunca se instala — PROBADO

- **Síntoma.** Armando un test propio copié la técnica del kit
  (`tools/tests/locucion-control.mjs`): reemplazar `speechSynthesis` por
  un motor falso que tarda 300ms por fragmento, para poder medir el caso
  "responder a MITAD de la locución". No medía nada: el motor falso no
  registraba una sola emisión.
- **Diagnóstico.** `locucion-control.mjs` instala su motor con una
  **asignación simple** dentro de `addInitScript`:
  `window.speechSynthesis = { … }`. `speechSynthesis` es un accessor de
  solo lectura del `Window`, así que en modo sloppy —que es como corre
  un `addInitScript`— **la asignación falla en silencio**: no tira, no
  avisa, y `window.speechSynthesis` sigue siendo el motor real.
- **Verificación, medida en el mismo Chromium de la suite**
  (`/opt/pw-browsers/chromium-1194`):
  - después de `window.speechSynthesis = {…}`, `getVoices()` sigue
    devolviendo la lista real (vacía en headless), no la del falso;
  - con `Object.defineProperty(window, 'speechSynthesis', {…})` sí queda
    una propiedad propia que tapa al accessor, y a partir de ahí el
    motor falso registra todo.
  Mi test usa `defineProperty` por eso, con el porqué escrito al lado.
- **El límite de lo que probé, y vale decirlo:** verifiqué que el motor
  falso NO se instala. **No** audité una por una las aserciones de
  `locucion-control.mjs` para decir cuáles quedan vacías — el test pasa
  en verde y algunas de sus cuentas (cuántas veces se llamó a
  `Narrador.speak`) siguen siendo válidas contra el motor real. Lo que sí
  es seguro es que el escenario por el que ese test dice existir
  —*"sin esto, el caso 'silenciar a mitad de la frase' —que es justo el
  que importa— no existe"*, dice su propio encabezado— no se está
  ejercitando.
- **Propuesta.** Cambiar las dos asignaciones por `defineProperty` (el
  test también reemplaza `SpeechSynthesisUtterance`, con el mismo
  problema) y, ya que estamos, que el propio test verifique que su motor
  quedó instalado antes de medir: dos líneas que convierten un test que
  puede volverse mudo en uno que avisa.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:461`
- `tools/tests/reporte-cliente.mjs:210`
