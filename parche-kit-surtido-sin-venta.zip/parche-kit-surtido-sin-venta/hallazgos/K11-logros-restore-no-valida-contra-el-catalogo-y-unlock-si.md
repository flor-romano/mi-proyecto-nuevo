# K11 · `Logros.restore()` no valida contra el catálogo y `unlock()` sí — PROBADO

- **Síntoma.** El chip del header mostró **"7/6 logros"**: más obtenidos
  que el total del catálogo. La grilla, mientras tanto, seguía dibujando
  6 tarjetas — o sea que el número miente y nada más lo delata.
- **Diagnóstico contra el código real.** Las dos puertas de entrada al
  mismo conjunto aplican criterios distintos (`coto-logros.js`):
  - `unlock(id)` valida: `var b = BADGES.filter(x => x.id === id)[0];
    if (!b) return false;` — un id que no está en el catálogo no entra.
  - `restore(s)` NO valida:
    `(s.b || []).forEach(function (id) { obtenidos[id] = true; });`
  Y el HUD hace `Object.keys(obtenidos).length + '/' + BADGES.length`,
  así que cualquier id de más infla el numerador contra un denominador
  fijo.
- **De dónde sale un id que ya no existe.** De probar builds sucesivos
  sobre la misma carpeta o el mismo LMS: `scorm-api.js` deriva su clave
  de respaldo de la RUTA del paquete, así que dos versiones del curso
  servidas desde el mismo lugar comparten estado. Si entre una y otra
  cambió el catálogo de logros, el id viejo sobrevive en el
  `suspend_data` y se sigue contando. Es la misma familia que §7.3
  punto 20 (el cliente probando builds encima del anterior).
- **Verificación.** Reproducido de forma determinística: se escribe un
  `suspend_data` con los 6 ids reales + `'fantasma'`, se recarga, y el
  chip dice exactamente `7/6` con 6 tarjetas dibujadas. Queda como
  chequeo permanente en `tools/tests/reporte-cliente.mjs`.
- **Lo que NO era.** La hipótesis del reporte —un logro contándose dos
  veces al reingresar a una diapositiva— no puede pasar: `obtenidos` es
  un conjunto indexado por id y `unlock()` corta con
  `if (obtenidos[id]) return false;`. Otorgar dos veces el mismo logro
  no suma dos.
- **Parche local.** Se filtra en `curso.js`, antes de llamar a
  `restore()`, contra el catálogo que vive ahí mismo — no se tocó el
  archivo del kit, así que el próximo zip de `kit-base/` no se lleva
  puesto el arreglo por accidente.
- **Propuesta.** Que `restore()` aplique el mismo criterio que
  `unlock()`: ignorar los ids que no estén en `BADGES`. Es una línea, y
  deja el invariante "obtenidos ≤ total" garantizado por el módulo en
  vez de por cada curso.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:293`
