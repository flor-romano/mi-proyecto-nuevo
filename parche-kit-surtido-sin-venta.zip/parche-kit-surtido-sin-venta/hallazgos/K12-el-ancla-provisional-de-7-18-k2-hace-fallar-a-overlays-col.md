# K12 · El ancla provisional de §7.18 K2 hace fallar a `overlays-colocados`, de forma intermitente — PROBADO

- **Síntoma.** `overlays-colocados` falló **1 de cada 3 corridas** con
  `[minijuego] (capa "mj-fin-ok") "d-place d-mj-fin-stat": cae fuera de
  su [data-shot] (0, 788 sobre 1600×780)`. En las otras dos, verde. Un
  test que a veces está rojo es exactamente lo que §6.60 / §7.3 punto 17
  dicen que enseña a mirar la suite y asumir que "siempre está así".
- **Diagnóstico.** Los dos overlays viven en un `[data-panel][hidden]`.
  Un `[data-shot]` oculto mide 0×0, así que `_initShots()` no puede
  calcular coordenadas y el motor les aplica su **ancla provisional**
  (`left:0; top:0`, kit-base v1.9.72, §7.18 K2) — que es una mejora
  deliberada, para que no caigan fuera del lienzo. El problema es que
  `overlays-colocados` revela la capa y mide **en el mismo turno
  sincrónico**, sin que el `ResizeObserver` llegue a correr: lo que mide
  es el ancla. Y el ancla, sobre `.d-mj-fin > .d-shot`, cae en (0, 788),
  fuera del `[data-shot]`.
  O sea: **la mitigación del kit dispara el test del kit.** La
  intermitencia viene de que el ancla solo se aplica
  `if (!h.style.left)` — una vez que algo posicionó los overlays de
  verdad, no vuelve.
- **Lo mismo, del lado del alumno.** Un `slidechange` sí dispara el
  recálculo; un `layerchange` **no**. Un curso que pone overlays dentro
  de capas depende del `ResizeObserver`, o sea de un frame de más: la
  primera vez que se abre el panel final, los dos números se pintan un
  instante en la esquina del arte y después saltan a su lugar.
- **Verificación.** Antes: 2 fallos en 6 corridas. Después de
  posicionar los paneles ocultos UNA vez al arranque (revelar → medir →
  volver a ocultar, todo en el mismo turno, sin que el navegador pinte
  en el medio): **10 corridas seguidas en verde**. Requiere además sacar
  `loading="lazy"` de esas dos imágenes — una imagen lazy dentro de un
  panel oculto no se descarga nunca, y sin `naturalWidth` `place()` sale
  por su guard y no hay nada que medir.
- **Propuesta.** Dos caminos, no excluyentes: que `_initShots()` se
  vuelva a correr ante `layerchange` igual que ante `slidechange` (es
  donde el kit ya tiene el resto de la familia "¿quién lo apaga?", y
  `initLayerVideos` es el precedente exacto para la mitad de video); y
  que `overlays-colocados` espere un frame entre revelar una capa y
  medirla, para no medir el ancla que el propio kit puso.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:441`
- `js/curso.js:1040`
- `js/curso.js:1065`
