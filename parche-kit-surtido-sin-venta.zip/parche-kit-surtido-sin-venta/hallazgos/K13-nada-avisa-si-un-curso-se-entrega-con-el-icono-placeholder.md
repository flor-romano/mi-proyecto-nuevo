# K13 · Nada avisa si un curso se entrega con el ícono placeholder — PROPUESTA, no bug

`new-course.mjs` deja en `img/icono-<cat>.webp` un WebP de **1×1
transparente**, y lo hace por una buena razón que documenta ahí mismo:
un `src` roto sería un 404, y la suite cuenta cualquier error de consola
como fallo, así que un curso recién generado arrancaría en rojo por un
asset que el diseñador todavía no entregó.

El costo es que la pastilla dorada del header se ve **vacía** y ningún
test lo nota: no hay error, el `src` resuelve, la imagen "existe". Este
curso se entregó así una vuelta entera. Un chequeo de una línea
—`naturalWidth <= 1` en el `<img>` de marca— lo convierte en un aviso.
Encaja en `markup-sanity` (que ya mira este tipo de cosas) o en
`gamificacion` (que ya decide si el curso "está en construcción" por
cantidad de contenido, y podría no exigirlo hasta ese piso).

### Lo que NO es relay

Cosas que aparecieron y que, mirándolas, son de este curso y no del kit:

- Que `.d-mj-body` sea de 2 columnas no es un bug: es el molde de
  "Seguridad alimentaria". Este PDF dispone el juego en filas, así que
  el curso pisa el grid. Es contenido.
- Que `--bg` (celeste de marca) se vea detrás del mini juego tampoco:
  es el default correcto para una diapositiva sin captura a sangre.
  Este PDF pone el juego sobre blanco, así que el curso lo pinta.
- Que `initShotSwap` dispare `onChange` N−1 veces está documentado y es
  lo correcto (la variante 0 se ve al entrar). Acá encaja perfecto: la
  variante 0 no es ningún concepto.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `index.html:134` — el ícono real del curso en la barra
