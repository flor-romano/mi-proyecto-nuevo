# K14 · Tope de 5 logros por curso — CONVENCIÓN NUEVA del cliente, no bug

**Qué pasó.** El cliente fijó, para TODOS los cursos y no solo para
este, un máximo de **5 logros** en el catálogo. Este curso tenía 6 y se
bajó a 5 fusionando los dos que medían lo mismo partido en dos.

**Por qué es del kit.** El catálogo de logros es contenido del curso
(así lo dice `coto-logros.js` en su cabecera, y está bien), pero el
**tope** no: es una regla de producto que vale para todos. Hoy nada la
sostiene — un curso nuevo puede declarar 8 logros y toda la suite pasa
en verde.

**Propuesta, dos piezas chicas:**

1. Anotarlo en `CLAUDE.md` §1, junto a "qué va en el kit y qué va en el
   curso": *el catálogo de logros lo define el curso, con un máximo de
   5*.
2. Un chequeo en `gamificacion.mjs`, que ya cuenta los logros del
   catálogo (imprime "5 logro(s) en el catálogo"): que falle por encima
   de 5. Es una línea, y convierte una regla verbal en una que no se
   puede olvidar.

Ojo con un detalle que este curso ya pagó: bajar el catálogo deja ids
viejos en el `suspend_data` de quien ya venía jugando, y el chip pasa a
decir "6/5". Eso es K11 (`Logros.restore()` no valida contra el
catálogo) visto desde otro ángulo — y es un argumento más para
arreglarlo en el kit, porque ahora **cualquier** curso que aplique este
tope va a pisarlo.


---

### Dónde está el parche local

No hay: este hallazgo no se puede resolver desde un curso. Es del kit.
