# K15 · El `.d-shot-hit-play` del kit no trae ícono, y su marcado de ejemplo tampoco — PROBADO

**Síntoma.** Siguiendo al pie de la letra el marcado que documenta
`coto-media.js` para el botón de play:

```html
<button type="button" class="d-shot-hit-play">Reproducir</button>
```

lo que se ve es el círculo azul del kit con la **palabra "Reproducir"**
adentro, en texto negro, desbordando el círculo — no un triángulo de
play.

**Diagnóstico contra el código real.** `coto-media.css` estiliza el
ícono asumiendo que alguien lo pone:

```css
.d-shot-hit-play svg { width: 40%; height: 40%; fill: #fff; margin-left: 8%; }
```

pero ni el CSS trae un `::before` de fallback ni `initInlineCircleVideos`
inyecta un `<svg>` (se verificó: el único `innerHTML` con un `<svg>` en
ese módulo es el del cartel de error, línea 165). O sea: el componente
está completo salvo el ícono, y el ejemplo de la documentación produce
un botón roto. El curso de referencia no lo destapa porque usa la
variante `--art`, con una imagen propia del cliente.

**Cómo se verificó.** Se montó el botón exactamente como lo documenta el
kit y se miró el render; después se puso el `<svg>` a mano y quedó bien
(64×64, círculo navy, triángulo blanco, hover y apagado al reproducir,
todo del kit).

**Propuesta.** Cualquiera de las dos, pero una:
- que `initInlineCircleVideos()` inyecte el `<svg>` del triángulo cuando
  el `.d-shot-hit-play` no tenga uno (y deje el texto como `.sr-only`),
  que es lo que hace el kit en otros lugares; o
- que el ejemplo de la documentación traiga el `<svg>` y un
  `<span class="sr-only">`, como lo escribió este curso.


---

### Dónde está el parche local

**Ya no está.** Era un `<svg>` inline en el marcado del `.d-shot-hit-play`.
Se borró en la undécima vuelta: las dos diapositivas de video pasaron a
video de fondo a 2520×1260 y ese patrón ya no existe en este curso. El
hallazgo sigue valiendo para el kit — cualquier curso que use
`initInlineCircleVideos` en su variante (c) se va a encontrar con lo
mismo. Si hace falta ver cómo era, está en el historial de git del
curso, antes de la undécima vuelta.
