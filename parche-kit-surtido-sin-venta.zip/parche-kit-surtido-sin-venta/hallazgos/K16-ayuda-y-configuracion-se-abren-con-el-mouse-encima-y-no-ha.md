# K16 · Ayuda y Configuración se abren con el mouse encima, y no hay forma de pedir "solo clic" — PROBADO

**Síntoma.** Los dos flotantes de abajo a la derecha abren su panel al
pasar el cursor por encima, sin clic. Reportado por el cliente.

**Diagnóstico contra el código real.** `coto-player-chrome.css` los
muestra con tres condiciones en OR:

```css
.d-fab:focus-within .d-fab-pop,
.d-fab.is-hover   .d-fab-pop,
.d-fab.is-open    .d-fab-pop { opacity:1; pointer-events:auto; visibility:visible; … }
```

`.is-open` es el pin por clic (`initPinnedPopover`, coto-player.js
§510). `.is-hover` la agrega `attachHoverGrace(it, 'is-hover', graceMs)`
en la misma función, sin opción de apagarlo: `initPinnedPopover` acepta
`graceMs` y `onOpen`, nada para decir "este grupo abre solo con clic".

No es un bug a secas —abrir con hover es una decisión de producto
razonable y está documentada como "la gracia"— pero **no se puede
elegir**, y el kit ya pagó dos parches alrededor de ese hover: el
`closeAll()` que tiene que sacar las dos clases (v1.9.40) y el `blur()`
del segundo clic, que existe solo para pelear contra `:focus-within`
(v1.9.72, §7.19 A5).

**Cómo se verificó.** Con el mouse sobre el botón, `visibility` del
`.d-fab-pop` daba `visible` sin ningún clic. Con el override del curso
da `hidden`, y `visible` recién al clickear. Está como punto 7 de
`tools/tests/reporte-cliente.mjs`.

**Workaround del curso** (en `pulido.css`, no en el kit): se apagan
`:focus-within` y `.is-hover` y se deja `.is-open`. Sacar
`:focus-within` no rompe el teclado, porque Enter sobre el botón
dispara el mismo `click`.

**Propuesta.** Una opción en `initPinnedPopover`, por ejemplo
`opts.soloClic`, que (a) no llame a `attachHoverGrace` y (b) agregue una
clase al contenedor —`.d-fab--solo-clic`— para que el CSS del kit pueda
excluirlo de las dos condiciones que no son el pin. Con eso el curso no
tiene que reescribir una regla del kit para cambiar de opinión sobre un
gesto.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `css/pulido.css:86`
