# K17 · El kit dice "el máximo posible del curso" para cualquier puntaje por encima del último nivel — PROBADO

**Síntoma.** El cliente mandó una captura del cierre con **189 puntos**
sobre un máximo de **199**, y debajo de la medalla decía *"189 puntos ·
el máximo posible del curso"*. No era el máximo.

**Diagnóstico contra el código real.** `pintarMedalla()`
(`coto-cierre.js` §361-363) busca el nivel inmediatamente superior al
puntaje y, si no hay ninguno, escribe ese texto:

```js
var sig = null;
for (var i = orden.length - 1; i >= 0; i--) if (orden[i].desde > puntos) { sig = orden[i]; break; }
if (!sig) sub.textContent = puntos + ' puntos · el máximo posible del curso';
```

O sea: "no queda medalla más arriba" se está traduciendo como "sacaste
el máximo". Son cosas distintas y la diferencia es todo el tramo entre
el último umbral y el máximo real — en este curso, 30 puntos.

Es un error de producto, no cosmético: le dice al alumno que ya no
tiene nada más que ganar cuando sí lo tiene, y a quien revisa el curso
le tapa un dato real.

**Cómo se verificó.** Se leyó el `[data-medalla-sub]` con un puntaje por
encima del umbral de oro y por debajo del máximo: dice "el máximo
posible del curso".

**Workaround del curso.** `corregirSubMedalla()` en `curso.js` reescribe
ese texto cuando el puntaje es menor que `MAX_SIN_VIDEOS`: *"N puntos ·
ya tenés la medalla más alta (el máximo del curso es M)"*.

**Propuesta.** Que `pintarMedalla` acepte el máximo del curso como dato
—el curso ya lo tiene calculado— y distinga los dos casos: "ya tenés la
medalla más alta" cuando no hay nivel superior, y "el máximo posible del
curso" solo cuando `puntos === máximo`. Sin ese dato el kit no puede
saber la diferencia, así que no alcanza con cambiar el texto.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:947`
