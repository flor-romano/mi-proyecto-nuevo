# K18 · El kit sabe que este curso no puede usar el recorte de tablet, pero no da forma de apagarlo — PROBADO

**Síntoma.** En iPad, las capturas —y sobre todo los videos de portada y
de unidad, donde se nota— salen recortadas a los costados.

**Diagnóstico contra el código real.** No hay que descubrirlo: está
escrito en la cabecera de `coto-shot-stage.css`, y nombra a este curso:

> "REQUIERE que el PDF del curso se haya diseñado con el margen de
> seguridad NUEVO (8% arriba/abajo + 13% a cada costado). Cursos
> diseñados con el margen VIEJO (8% parejo en las 4 direcciones,
> **ej. «Surtido sin venta»**) NO deben usar este archivo — el recorte
> que habilita en el rango tablet caería sobre contenido real, no sobre
> margen vacío. Para esos cursos, seguir usando el bloque estático de
> solo-lienzo-fijo (sin el @container de abajo)."

El `@container (min-aspect-ratio: 1.5) and (max-aspect-ratio: 2.2)`
(§341) estira `.d-shot` a `100cqw × 100cqh` y deja que
`object-fit:cover` recorte. Medido en un iPad apaisado (1180×820 →
escenario 1180×700, proporción 1.686, dentro del rango): el recorte es
el **15.7% del ancho**, 93px por costado sobre un arte 2:1.

**Y acá está el hallazgo, que no es la regla sino la forma de no
traerla:** `new-course.mjs` copia `coto-shot-stage.css` entero. La
instrucción de la cabecera —"no uses este archivo"— no se puede cumplir
sin romper todo lo demás que el archivo define (la base del escenario,
las diapositivas, el Ken Burns, el aviso de girar el dispositivo). En la
práctica, un curso con margen viejo **no tiene cómo** quedarse fuera de
ese `@container`, más allá de pisarlo a mano.

**Cómo se verificó.** Se midió la proporción de `.d-shot` en 1180×820 y
en 1440×900: daba 1.686 y 1.846 en vez de 2. Con el override del curso
da 2 en los dos casos. Está como punto 17 de
`tools/tests/reporte-cliente.mjs`.

**Propuesta.** Que el recorte de tablet dependa de una clase o una
variable que el curso declare —por ejemplo `.d-stage[data-margen="nuevo"]`
o `--shot-recorte-tablet: 0|1`— con el default en "no recortar". Así un
curso con margen viejo hereda lo seguro sin tener que reescribir una
regla del kit, y uno con margen nuevo lo habilita en una línea. Hoy el
default es el que puede comerse contenido.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `css/pulido.css:244`
