# K19 · `showPopup()` enfoca el primer campo de texto, y en iPadOS eso dispara el cartel de "estás escribiendo" — PROBADO

**Síntoma.** En iPad, interactuando por touch, aparece repetidamente el
cartel del sistema *"Parece que estás escribiendo mientras estás en
pantalla completa"*.

**Diagnóstico contra el código real.** `Motor.showPopup()`
(`motor-slides.js` §929) hace:

```js
var focusable = pop.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
if (focusable) focusable.focus();
```

En el glosario del boilerplate, el primer `input` es el buscador
(`<input data-gloss-search type="search">`). iPadOS muestra ese cartel
cuando una página en pantalla completa tiene el foco en un campo de
texto — así que el cartel sale **cada vez que el alumno abre el
glosario**.

Enfocar dentro del pop-up está bien y hace falta (atrapa-foco,
lectores de pantalla). Lo que no corresponde es elegir un campo de
TEXTO cuando el que abre es un dedo: nadie va a tipear, y el costo es
un cartel del sistema encima del curso.

**Cómo se verificó.** En un contexto táctil (820×1180, `hasTouch`), se
abrió el glosario y se leyó `document.activeElement`: daba
`INPUT[type=search]`. Con el parche del curso queda la tarjeta del
pop-up, que sigue estando adentro del diálogo. Punto 18 del test.

**Propuesta.** Que `showPopup()` no elija campos de texto cuando
`matchMedia('(pointer: coarse)')` da verdadero, y caiga en el primer
botón o en la propia tarjeta. Dos líneas, y saca un cartel del sistema
de encima de todos los cursos.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:383`
