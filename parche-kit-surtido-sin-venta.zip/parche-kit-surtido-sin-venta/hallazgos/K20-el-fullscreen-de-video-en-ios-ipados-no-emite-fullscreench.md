# K20 · El `fullscreen` de video en iOS/iPadOS no emite `fullscreenchange`, así que el reproductor vuelve mal ubicado — PROBADO por síntoma

**Síntoma.** En iPad, después de dar play el reproductor "se tilda": no
se puede agrandar ni achicar correctamente.

**Diagnóstico contra el código real.** El kit ya resolvió el bug de
fondo y lo documenta en `coto-media.js`: el video vive dentro de una
captura posicionada en píxeles por `_initShots()`, y entrar o salir de
pantalla completa no dispara ningún resize, así que al volver queda mal
ubicado. El fix del kit es escuchar `fullscreenchange` y volver a correr
`_initShots()`.

Pero **Safari de iOS/iPadOS no emite `fullscreenchange`** para el
fullscreen nativo de un `<video>`: emite `webkitbeginfullscreen` y
`webkitendfullscreen` sobre el propio elemento. O sea que en el
dispositivo donde más se usa esa pantalla completa, el fix no corre
nunca.

**Cómo se verificó.** No se pudo reproducir el fullscreen nativo de iOS
en el Chromium de la suite; lo que se verificó es el mecanismo — que el
kit solo registra `fullscreenchange`, y que con los dos eventos de
WebKit agregados el recálculo se dispara. El síntoma es el que reportó
el cliente en un iPad real.

**Propuesta.** Registrar los tres eventos en el mismo handler:
`fullscreenchange`, `webkitbeginfullscreen` y `webkitendfullscreen`.
Conviene además recalcular dos veces (en el evento y ~120ms después):
al volver de pantalla completa el layout no está estabilizado en el
mismo turno.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:383`
