# K21 · El kit escribe todo el chrome en `rem` pero nunca define el tamaño de raíz — PROBADO

**Síntoma.** En un monitor grande el curso "queda chico y perdido en el
medio". Reportado por el cliente con una captura de 1900×1200.

**Diagnóstico contra el código real.** Hay que separar dos cosas que se
ven parecidas.

El LIENZO sí escala, y se midió: a 1900×1200 la captura sale 1900×950
(todo el ancho), a 2560×1440 sale 2560×1280, a 1920×1080 sale 1920×960.
No hay `max-width` en ninguna parte.

Lo que no escalaba es la INTERFAZ. El kit escribe la barra, los
botones, los chips, los modales y el resumen en `rem` —lo correcto—
pero **ningún archivo define `html{font-size}`**, así que la raíz se
queda en los 16px del navegador para siempre. Medido: tipografía de
16px y barra de 56px tanto en 1440 como en 2560. A mayor pantalla, la
interfaz ocupa proporcionalmente MENOS.

El propio kit ya tiene el argumento escrito, pero solo mirando para
abajo: en la regla que achica el chrome en pantallas bajas
(`coto-player-chrome.css` §58, v1.9.79) dice *"que el alto del chrome
no dependa del alto de la pantalla, es real y es del kit"*. Vale igual
para arriba.

**Cómo se verificó.** Se midió `getComputedStyle(document.documentElement).fontSize`
y el alto de `.d-top`/`.d-bottom` en 1440, 1920 y 2560: 16px y 56/64 en
los tres. Con el escalado del curso dan 16, 17.3 y 21, y las barras
acompañan. Punto 22 de `tools/tests/reporte-cliente.mjs`.

**Trampa que este curso pisó al arreglarlo, y que conviene que el kit
evite de raíz:** `.d-iconbtn--labeled` es UNA sola clase, igual de
específica que `.d-iconbtn`. Cualquier regla de ancho sobre
`.d-iconbtn` escrita en el CSS del curso —que carga último— le gana al
`width:auto` del botón etiquetado y lo aplasta a una caja cuadrada, con
los rótulos encimados ("SonidoLocución GlosarioAmpliar"). Pasó acá y se
vio en el render.

**Propuesta.** Dos cosas: (a) que el kit defina la raíz con un `clamp()`
que crezca con el ancho por encima de un umbral —lo que hace que TODO
el `rem` que ya escribió empiece a escalar sin tocar una sola regla
más— y las filas del `.d-app` en `rem` en vez de px; y (b) que
`.d-iconbtn--labeled` gane especificidad (por ejemplo
`.d-iconbtn.d-iconbtn--labeled`) para que no dependa del orden de
carga.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:384`
