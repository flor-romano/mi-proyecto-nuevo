# K22 · `initBgVideos()` da por perdido cualquier error que no sea `NotAllowedError` — PROBADO

**Síntoma.** El video de fondo de la portada queda en la imagen fija al
entrar al curso, y **recién arranca si el alumno avanza una diapositiva
y vuelve**. Reportado por el cliente, con el curso en su visor.

**Diagnóstico contra el código real.** El cable está: `initBgVideos()`
termina con `var cur = global.motor.current(); if (cur) sync(...)`
(`coto-media.js`), así que la diapositiva activa del arranque sí recibe
su `attempt()`. El problema es CUÁNDO: en ese instante el `<video>`
acaba de nacer y todavía está resolviendo su fuente, así que ese
`play()` rechaza con `AbortError` ("interrupted by a new load
request") — no con `NotAllowedError`.

Y el `catch` de `attempt()` trata un solo error como recuperable:

```js
var recuperable = err && err.name === 'NotAllowedError';
if (!recuperable || !videoUsable(v)) { if (tap) tap.hidden = true; return; }
```

Cualquier otro error **esconde el botón de gesto y no vuelve a intentar
nunca**. Al reentrar, el archivo ya está en caché, `play()` resuelve, y
por eso "anda si vuelvo". El reintento mudo de K10 (v1.9.72) resolvió
el caso del autoplay bloqueado, que es el otro; este quedó afuera.

Ojo con la consecuencia secundaria, que es la que hace que el arreglo
del curso no alcance con reintentar: como el kit ya escondió el
`.d-shot-video-tap`, si el reintento sale mudo el alumno se queda sin
forma de pedir el audio. Hay que volver a mostrarlo con
`data-modo="sonido"` (el contrato que el propio kit ya engancha: ese
clic solo saca el mute, sin reiniciar el video).

**Cómo se verificó.** Punto 23 de `tools/tests/reporte-cliente.mjs`: se
simula el rechazo del primer `play()` con `AbortError` y un medio sano
(los `.mp4` del paquete son placeholders de 0 bytes, así que un
`<video>` real termina en `error` y no prueba nada). Sin el reintento
del curso: 1 intento y el video pausado. Con él: reintenta y arranca.
La primera versión del test simulaba `NotAllowedError` y **pasaba
igual con el arreglo desactivado** — porque ESE el kit ya lo maneja;
quedó anotado en el comentario del test para que no vuelva a escribirse
así.

**Propuesta.** Reintentar también ante `AbortError` (y, en general,
cuando el medio todavía no tiene datos), enganchando `loadeddata` /
`canplay` una vez y volviendo a pasar por `attempt()` — no por un
`play()` crudo, para no perder el `currentTime`, el volumen y el manejo
del botón de gesto que `attempt()` ya hace.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:325`
- `js/curso.js:487`
