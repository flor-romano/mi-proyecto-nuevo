# K23 · No hay forma de saber si el alumno eligió velocidad de locución — PROBADO

**Síntoma.** El cliente pidió que en iPad la locución arranque a 0.85x.
El cambio tiene que ser un DEFAULT: si el alumno ya movió el control de
velocidad, manda su elección.

**Diagnóstico contra el código real.** `narrador.js` expone
`setRateFactor()` y `getRateFactor()`, y persiste la elección en
`localStorage` bajo `coto-diapos-rate`. Pero `getRateFactor()` devuelve
un número siempre: `1` tanto si el alumno eligió 1x como si nunca tocó
nada. No hay ninguna API que distinga "valor por defecto" de "valor
elegido", así que el curso no tiene forma de poner un default sin
arriesgarse a pisar una preferencia guardada.

Desde el curso se resuelve leyendo la clave del `localStorage` a mano
(`window.localStorage.getItem('coto-diapos-rate') !== null`), que es
exactamente el tipo de acoplamiento a un detalle interno del kit que
§0.1 pide evitar: si el kit renombra la clave, el curso se rompe en
silencio.

**Cómo se verificó.** Punto 28 de `tools/tests/reporte-cliente.mjs`:
táctil sin elección previa → 0.85x; táctil con `1.2` guardado y
recarga → 1.2x; escritorio → 1x.

**Propuesta.** Dos opciones, cualquiera sirve: (a) un
`Narrador.hasUserRate()` que diga si la preferencia está guardada, o
(b) un `Narrador.setDefaultRateFactor(f)` que aplique el valor **solo
si** el alumno todavía no eligió. La (b) es la que deja el código del
curso en una línea.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:326` — velocidadPorDefectoEnTactil(): lee la clave interna del localStorage porque no hay API
