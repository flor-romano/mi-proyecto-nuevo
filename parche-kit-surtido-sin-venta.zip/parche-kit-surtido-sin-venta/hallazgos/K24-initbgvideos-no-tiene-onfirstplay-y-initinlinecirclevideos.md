# K24 · `initBgVideos()` no tiene `onFirstPlay` y `initInlineCircleVideos()` sí — PROBADO

**Síntoma.** Un curso que mueve una diapositiva del patrón 3 (video
chico dentro del arte) al patrón 1 (video de fondo) pierde los puntos y
el logro por verlo, sin ningún error.

**Diagnóstico contra el código real.** Los dos patrones viven en el
mismo archivo y resuelven el mismo problema de negocio —"¿el alumno vio
este video?"— con contratos distintos. `initInlineCircleVideos(opts)`
toma `seen` / `markSeen` / `onFirstPlay`; `initBgVideos(opts)` toma
`bgVideoAutoMudo` y nada más. Mover una diapositiva de un patrón al
otro obliga a reescribir a mano el enganche de puntaje, que es
justamente la parte que ningún test del kit mira.

**Cómo se verificó.** Pasó acá: las dos diapositivas de video del
cuerpo cambiaron de patrón (§24.2) y hubo que escribir el listener de
`playing` en `curso.js`. Punto 12 del test del curso cubre el resto del
contrato de esas diapositivas, pero el puntaje quedó del lado del curso.

**Propuesta.** Que `initBgVideos()` acepte el mismo trío
`seen`/`markSeen`/`onFirstPlay`. Y que el ejemplo use `playing` y no
`play`: `play` se dispara también cuando el navegador lo intenta y
rechaza, así que un curso que escuche `play` paga un video que el
alumno nunca vio.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:532`
