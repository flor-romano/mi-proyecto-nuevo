# K25 · Los overlays de una diapositiva no visitada llegan SIN medidas — PROBADO

**Síntoma.** Reportado por el cliente como *"al iniciar cada
diapositiva el contenido aparece y se agranda un poquito de golpe, como
un rebote"*.

**Diagnóstico contra el código real.** `_initShots()` posiciona cada
`[data-hit]` / `[data-place]` escribiendo `left/top/width/height` en px
contra la caja renderizada de la imagen. Una diapositiva que todavía no
se visitó está en `display:none`: mide 0×0, `place()` se va sin escribir
nada, y el overlay queda en su tamaño de contenido hasta que el alumno
entra. El kit **ya sabe que esto pasa** —tiene un "ancla provisional"
que los manda a (0,0) para que al menos no caigan fuera del lienzo
(v1.9.72, §7.18 K2)— pero el ancla trata el síntoma de estar en un
lugar absurdo, no el de llegar sin medidas.

Y hay una segunda mitad que las agrava: la captura suele ser
`loading="lazy"` dentro de ese `display:none`, así que el navegador ni
la pide. Sin imagen cargada no hay `naturalWidth`, y sin eso `place()`
no puede calcular nada **ni siquiera al entrar**, hasta que la imagen
termine de bajar.

**Cómo se verificó.** Medido al arrancar el curso: 25 overlays en 6
diapositivas, ninguno con `left/top/width/height`. Medido al entrar a
"Últimos consejos": un panel pasa de 26×5 en (20,56) a 310×74 en
(645,158). Y se grabó la transición cuadro a cuadro para descartar que
fuera una animación: el ancho del dibujo no cambia en ninguno de los 74
cuadros. Puntos 29 y 30 de `tools/tests/reporte-cliente.mjs`.

**Propuesta.** Que `_initShots()` coloque TODOS los `[data-shot]` desde
el arranque, no solo los que miden: cuando un shot mide 0×0 puede tomar
la caja de cualquier otro shot visible del mismo tipo (en un curso de
captura íntegra son todos el mismo lienzo). Y que sondee el tamaño
natural con un `Image()` suelto cuando el `<img>` todavía no cargó —
además de dar la medida, deja el archivo en caché y la captura tampoco
aparece de golpe. Es lo que terminó haciendo este curso a mano
(`precolocarOverlays` en `curso.js`).

**Aparte, y de producto:** `_initHitStagger()`/`_initPlaceStagger()`
escalonan la entrada de cada overlay con `.d-stagger-in`
(`translateY(8px)`) a 45ms y 90ms por elemento. Con 5 paneles el último
arranca a los 360ms, después de que la diapositiva ya terminó su
fundido de 300ms. Es la misma discusión que el Ken Burns (§E1): un
cliente lo pidió, otro lo objeta. Convendría la misma solución — una
variable para apagarlo sin pelearse con el JS que agrega la clase en
cada `slidechange`.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `js/curso.js:818` — `precolocarOverlays()` y la sonda de tamaños:
  coloca los 25 overlays al arrancar y deja las capturas en caché.
- `css/pulido.css` — el bloque "La diapositiva entra en fundido y nada
  más": apaga `.d-stagger-in` y el `scale(.98)` de entrada del pop-up.
- `tools/tests/reporte-cliente.mjs` — puntos **29** (mide el síntoma:
  nada cambia de caja entre el primer cuadro y el último) y **30** (mide
  la causa: las dos animaciones inertes). Los dos se probaron al revés,
  desactivando cada arreglo.
