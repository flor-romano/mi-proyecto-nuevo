# K26 · `video-fondo.mjs` no prevé el "contenedor vacío" — PROBADO

**Síntoma.** El test exige `poster` en todo `.d-shot-slide--bg-video`.
Un curso donde la diapositiva ES el video —contenedor vacío a la espera
del archivo— no puede ponerlo, y la única salida es tocar un test del
kit.

**Diagnóstico contra el código real.** El chequeo es correcto para el
caso que preveía: arte + video, donde el `poster` es ese arte y cubre
el hueco mientras el `.mp4` no está. Pero el kit soporta los dos usos
del patrón 1 y el test solo contempla uno.

**Cómo se verificó.** Pasó acá (§24.2): el cliente pidió las dos
diapositivas de video vacías, "sin contenido de placeholder", y el test
las marcó en rojo.

**Propuesta.** Que el test honre un opt-out explícito en el marcado
(acá se usó `data-sin-poster`) y que lo aplique solo a ese chequeo. Es
la única divergencia del curso respecto de un test del kit y está
marcada como tal en el archivo.


---

### Dónde está el parche local, en `codigo-del-curso/`

Es la implementación que YA funciona en producción. No para copiarla tal
cual: el curso la escribió para su caso. Sirve para ver la forma.

- `tools/tests/video-fondo.mjs:98`
