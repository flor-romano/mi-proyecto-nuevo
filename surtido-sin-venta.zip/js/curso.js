/* ============================================================
   curso.js — "Surtido sin venta" (Área Salón · COTO)
   ------------------------------------------------------------
   El ÚNICO archivo que se escribe entero. Todo lo demás (motor,
   narrador, player, media, ui, piezas, logros, cierre) vive en los
   módulos del kit y no se toca: la pregunta de CLAUDE.md §1 es
   siempre "¿esto lee algo de ESTE curso?". Si la respuesta es no, va
   al kit — y el fix se relaya, nunca se edita `kit-base/` desde acá
   (§0.1).

   Lo que hay acá, en orden:
     1. vocabulario propio para la locución
     2. contenido: textos de los 7 conceptos y banco del mini juego
     3. tabla de puntos + umbrales de medalla (derivados, no elegidos)
     4. catálogo de logros
     5. persistencia (suspend_data)
     6. boot(): cableado de los módulos del kit
   ============================================================ */
(function () {
  'use strict';

  var COURSE_SLUG = 'surtido-sin-venta';
  var COURSE_NAME = 'Surtido sin venta';

  /* ---------- 1 · Vocabulario propio para la locución ----------
     El diccionario base del kit ya trae la tabla oficial del Manual de
     Contenido (PLU, ticket, online, y el deletreo de códigos de 5 a 8
     dígitos — o sea que "574027" ya se lee dígito por dígito). Acá van
     solo las siglas de ESTE curso. */
  if (window.Narrador && Narrador.addFixes) {
    Narrador.addFixes([
      [/\bEAN\b/g, 'eán'],
      [/\bGESCOM\b/gi, 'guescóm'],
      [/(\d)\s*cc\b/gi, '$1 centímetros cúbicos'],
      /* "A (Alta)" / "B (Media)" / "C (Baja)": sin esto el paréntesis
         se lee como una pausa seca en medio de la clasificación. */
      [/\b([ABC])\s*\(([^)]+)\)/g, '$1, $2,']
    ]);
  }
  /* El minijuego arma sus opciones con `innerHTML`, así que sus botones
     tienen que entrar en el selector que mira `Narrador.textOf()` — si
     no, la diapositiva del juego narra la consigna y se queda muda en
     las cuatro respuestas (CLAUDE.md §1, narración de contenido con
     render propio en JS). */
  if (window.Narrador && Narrador.addTextSel) {
    Narrador.addTextSel('.d-mj-opt');
    /* El pop-up "Cómo recorrer el curso" que genera el kit narraba
       VACÍO: su tarjeta usa `<h3>` + `<b>`/`<span>` dentro de
       `.d-instr-card`, y ninguno entra en el selector de
       `Narrador.textOf()` (que sí contempla `.d-instr-item`, la clase
       del acordeón de Ayuda — otra pieza). Verificado leyendo la
       salida real de `textOf()` sobre ese pop-up: cadena vacía.
       Es del kit y está relayado; mientras tanto se suma acá. */
    Narrador.addTextSel('.d-instr-modal h3, .d-instr-card > div > b, .d-instr-card > div > span');
  }

  /* ---------- 2 · Contenido ---------- */

  /* Los 7 conceptos. El ÍNDICE coincide con `data-shot-swap-go` del
     marcado: 0 es la pantalla sin concepto elegido (la que se ve al
     entrar) y por eso no tiene texto propio. */
  var CONCEPTOS = [
    null,
    { id: 'plu', nom: 'PLU y EAN',
      txt: 'PLU y EAN: los dos códigos que identifican a cada producto. ' +
           'PLU, código interno: es el número que Coto le asigna a cada producto dentro de su sistema, no aparece en el envase. ' +
           'EAN, código de barras: es el número largo que está debajo del código de barras en el envase, es el mismo en todos los supermercados y lo pone el fabricante.' },
    { id: 'stock', nom: 'Stock',
      txt: 'Stock: es la cantidad de unidades que tenemos de un producto, tanto en góndola como en depósito. ' +
           'Por ejemplo: si hay 6 en góndola y 10 en depósito, el stock total es 16.' },
    { id: 'falso', nom: 'Falso stock',
      txt: 'Falso stock: cuando el sistema indica que tenemos una cierta cantidad de stock, pero en la góndola y el depósito hay menos unidades de las que figura. ' +
           'Por ejemplo: el sistema dice 20 unidades de gaseosa, pero al contar físicamente solo hay 12. Esas 8 unidades de diferencia son el falso stock, un error que hay que analizar y corregir.' },
    { id: 'rotacion', nom: 'Rotación',
      txt: 'Rotación: es qué tan rápido se vende un producto en la clase determinada. Según cuánto se vende, cada producto tiene una rotación. ' +
           'A, alta: se vende mucho y seguido. B, media: se vende con frecuencia moderada. C, baja: se vende poco o muy lentamente.' },
    { id: 'exhibicion', nom: 'Exhibición',
      txt: 'Exhibición: es cómo está presentado el producto en el salón de ventas, si está bien ubicado, a la altura de los ojos, con el frente visible y con precio. ' +
           'Una buena exhibición hace que el producto se vea y se venda. Una mala exhibición, con el producto escondido, dado vuelta o sin precio, puede hacer que no se venda aunque haya stock.' },
    { id: 'surtido', nom: 'Surtido',
      txt: 'Surtido: es la totalidad de los productos que tenemos disponibles para vender en los diferentes sectores de una sucursal.' },
    { id: 'gescom', nom: 'GESCOM',
      txt: 'GESCOM, Gestión Comercial: es el sistema interno que usamos en Coto para consultar reportes y ver el stock de cada producto, entre otras cosas. ' +
           'En este caso vas a usarlo para armar y leer el reporte de surtido sin venta.' }
  ];

  /* Banco del mini juego — las 5 pantallas del PDF (páginas 23 a 27).
     `ok` es el índice de la opción correcta; el orden de las opciones
     es el del arte, no se baraja: la escena está horneada en la imagen
     y el alumno la lee de izquierda a derecha igual que en el papel. */
  var MJ = [
    { id: 'q1', escena: 'img/mj-escena-1.webp',
      consigna: 'Es el número que Coto le asigna a cada producto dentro de su sistema. No aparece en el envase. ¿De qué concepto hablamos?',
      opts: ['PLU', 'Stock', 'EAN', 'Falso stock'], ok: 0,
      why: 'El PLU es el código interno de Coto. El EAN es el de barras del envase, que pone el fabricante.',
      mal: 'Ojo: ese dato sí aparece en el envase o mide otra cosa. El código interno del sistema es el PLU.' },
    { id: 'q2', escena: 'img/mj-escena-2.webp',
      consigna: 'Es un reporte que, según la cantidad de días que elijas, muestra los productos que no se vendieron en ese tiempo. ¿Qué control es?',
      opts: ['Control de rotación', 'Control de surtido sin venta', 'Control de exhibición', 'Control de GESCOM'], ok: 1,
      why: 'Es el control de surtido sin venta: lista los productos sin movimiento en la cantidad de días que elijas.',
      mal: 'Ese control mira otra cosa. El que lista los productos sin movimiento por cantidad de días es el de surtido sin venta.' },
    { id: 'q3', escena: 'img/mj-escena-3.webp',
      consigna: 'Para mejorar la venta de un producto nuestro sector puede, entre otras opciones, hacer una de estas cosas. ¿Cuál?',
      opts: ['Ponerlo cerca de línea de cajas', 'Pedir más espacio en góndola', 'Ponerle un cartel de novedad', 'Regalar una muestra'], ok: 1,
      why: 'Nuestro sector puede pedir un cambio de lugar, más espacio en góndola, una oferta, o analizar si conviene tenerlo en el surtido.',
      mal: 'Esa acción no depende de nuestro sector. Lo que sí podemos pedir es un cambio de lugar, más espacio en góndola o una oferta.' },
    { id: 'q4', escena: 'img/mj-escena-4.webp',
      consigna: 'La rotación es qué tan rápido se vende un producto en la clase determinada. A (Alta): se vende mucho y seguido. B (Media): se vende con frecuencia moderada. ¿Y la C?',
      opts: ['C (Baja): se venden pocos', 'C (Baja): no se vende', 'C (Baja): no hay stock', 'C (Baja): se vende poco o lento'], ok: 3,
      why: 'La rotación C es baja: el producto se vende poco o muy lentamente. Que rote poco no quiere decir que no se venda ni que falte stock.',
      mal: 'Rotación baja no es lo mismo que "no se vende" ni que "no hay stock": es que se vende poco o muy lentamente.' },
    { id: 'q5', escena: 'img/mj-escena-5.webp',
      consigna: 'Es el número largo que está debajo del código de barras en el envase. Es el mismo en todos los supermercados y lo pone el fabricante. ¿Qué es?',
      opts: ['Surtido', 'Sobre stock', 'EAN', 'PLU'], ok: 2,
      why: 'El EAN es el código de barras del envase. Es el mismo en todos los supermercados porque lo pone el fabricante.',
      mal: 'El código del envase, igual en todos los supermercados, es el EAN. El PLU es el interno de Coto.' }
  ];

  /* ---------- 3 · Puntaje ----------
     Diseñado contra las 3 patologías de §7.14 (el puntaje no puede
     premiar insistencia en vez de precisión):
       · lo que el gate YA obliga a hacer pesa poco (74 de 199);
       · NO hay premio binario por "completar el mini juego" — terminarlo
         es requisito de avance, no puntaje;
       · la parte que sí evalúa (el mini juego) pesa 125 de 199, y lo
         que decide cuánto paga cada pregunta es haberla acertado SIN
         haber errado antes: reintentar recupera 10, nunca los 25.
     Los tres umbrales NO se eligen: salen del máximo medido con un
     recorrido instrumentado (`tools/tests/puntaje-curso.mjs`), y se
     verifican ahí — la tabla es una intención, el contador es el hecho
     (§7.3 punto 19). */
  var PTS = {
    concepto: 6,     // x7  = 42   (explorar: no se toca, es el aprendizaje)
    ficha: 8,        // x4  = 32
    video: 10,       // x2  = 20   ← HOY no se puede ganar: los .mp4 son placeholder
    mjBien: 25,      // x5  = 125  (acierto sin haber errado antes esa pregunta)
    mjBienTrasError: 10
  };
  /* Máximo alcanzable HOY (sin los videos reales) = 42 + 32 + 125 = 199.
     Con los videos cargados pasa a 219; los umbrales siguen valiendo.
     Piso garantizado por el gate = 104, y subió: desde que avanzar exige
     APROBAR el mini juego (3 de 5, pedido del cliente), el recorrido
     más barato que el gate acepta ya no es "terminarlo perdiendo" sino
     "aprobarlo a los tropezones" — los 7 conceptos (42) + las 4 fichas
     (32) + 3 aciertos pagados tras error (3×10 = 30). Medido con
     `_auto('minimo')`: 104. El bronce arranca ahí, así que quien
     termina el curso nunca se queda sin medalla (§6.10.6).

     LOS TRES UMBRALES SALEN DE RECORRIDOS MEDIDOS, no de repartir el
     máximo en tercios (§7.3 punto 19). Medido con `_auto()` sobre el
     curso entero, con todo el contenido explorado:

       recorrido            juego                       puntaje
       ------------------------------------------------------------
       mínimo               3 de 5, las 3 tras errar        104
       insistente           5 de 5, cada una tras un error  124
       perfecto             5 de 5 a la primera             199

     · bronce = 104 — el piso que el gate garantiza. Quien termina el
       curso tiene medalla, siempre. Antes era 74, que era el piso
       cuando alcanzaba con TERMINAR el juego; ahora hay que aprobarlo,
       y aprobarlo paga.
     · plata = 124 — el recorrido insistente, EXACTO. Antes estaba en
       127 y era un umbral imposible de una forma que no se veía: quien
       exploraba todo el curso y terminaba el juego acertando las cinco
       —pero tropezando en cada una— se quedaba 3 puntos abajo de plata.
       Un umbral que ningún recorrido real alcanza es peor que uno alto:
       no se lee como "me faltó", se lee como "está roto".
     · oro = 169 — todo el contenido (74) + los 5 conceptos acertados
       permitiendo hasta dos con un error previo (3×25 + 2×10 = 95).
       Antes estaba en 180, que deja 19 puntos de aire sobre el máximo:
       DOS tropiezos en el mini juego (15 puntos cada uno) y el oro se
       volvía inalcanzable por más que el alumno hubiera hecho todo.
       Eso es lo que el cliente reportó como "no se puede llegar a oro".

     Aclaración sobre lo que el cliente supuso: los LOGROS nunca
     bloquearon la medalla. `medallaDe()` (coto-cierre.js §336) compara
     puntos contra umbrales y nada más; el catálogo de logros no entra
     en la cuenta. Lo que bloqueaba era el aire entre 180 y 199. */
  var MAX_SIN_VIDEOS = 199;
  var PISO_GATE = 104;
  var NIVELES = [
    { id: 'bronce', desde: PISO_GATE, nombre: 'bronce', icono: '🥉' },
    { id: 'plata', desde: 124, nombre: 'plata', icono: '🥈' },
    { id: 'oro', desde: 169, nombre: 'oro', icono: '🥇' }
  ];

  /* Reglas del mini juego, en sus propios puntos (los de la tarjeta
     amarilla del arte). Salen de los números que el PDF ya muestra:
     1000 de arranque, 2350 con 5 de 5 → +270 por acierto; y 1150 con
     1 acierto y 3 vidas perdidas → −40 por error. */
  var MJ_INICIAL = 1000, MJ_ACIERTO = 270, MJ_ERROR = 40, MJ_VIDAS = 3;
  /* Cuántos de los 5 conceptos hay que acertar para APROBAR el juego
     (pedido del cliente). Es solo el umbral de la pantalla final —
     "¡Terminaste con éxito!" contra "Estuviste cerca…"—: no toca los
     puntos del curso, que los paga cada acierto por separado, ni el
     logro `preciso`, que sigue pidiendo 5 de 5 sin un solo error. */
  var MJ_APROBACION = 3;

  /* ---------- 4 · Catálogo de logros ----------
     Ninguno depende de un video: con los .mp4 en placeholder serían
     logros imposibles de obtener (§3.9). */
  var BADGES = [
    { id: 'conceptos', nom: 'Explorador', ic: '🔎',
      txt: 'Abriste los 7 conceptos del curso.',
      pista: 'Abrí los 7 conceptos de "Algunos conceptos importantes".' },
    /* `repaso` reemplaza a los dos logros que había antes ("Sabés
       armarlo" por las 2 fichas del primer video y "Manos a la obra"
       por las 2 del segundo): el cliente fijó un tope GENERAL de 5
       logros por curso, y de los 6 que había estos dos eran los únicos
       que medían lo mismo —abrir fichas de repaso— partido en dos. Se
       fusionan en uno solo por las 4, así el tope se cumple sin sacar
       ninguna conducta del tablero. Los ids viejos siguen apareciendo
       en el `suspend_data` de quien ya venía jugando: los descarta
       `sanearLogros()`, que filtra contra este catálogo. */
    { id: 'repaso', nom: 'Buen repaso', ic: '📋',
      txt: 'Abriste las 4 fichas de repaso de los dos videos.',
      pista: 'Abrí las 4 fichas de "Lo que vimos en este video".' },
    { id: 'juego', nom: 'Jugador', ic: '🎮',
      txt: 'Terminaste el mini juego.',
      pista: 'Terminá el mini juego, con o sin errores.' },
    { id: 'preciso', nom: 'Sin errores', ic: '🎯',
      txt: 'Acertaste los 5 conceptos del mini juego sin equivocarte ni una vez.',
      pista: 'Acertá los 5 conceptos del mini juego sin errar ninguno.' },
    { id: 'curso', nom: 'Curso completo', ic: '🏅',
      txt: 'Completaste "Surtido sin venta".',
      pista: 'Llegá al final del curso.' }
  ];
  /* Las 4 fichas de repaso, en un solo lugar: las usa `premiarFicha()`
     para decidir qué pop-up paga y el logro `repaso` para saber cuándo
     están las cuatro. Antes la lista estaba escrita dos veces. */
  var FICHAS = ['rep-para-que', 'rep-como', 'rep-acciones', 'rep-mejorar'];

  var Logros = null;   // lo crea boot(), cuando el DOM ya existe

  /* ---------- 5 · Estado y persistencia ----------
     Claves cortas: `suspend_data` tiene 4096 caracteres contados en
     SCORM 1.2 y `saveState()` rechaza en silencio si se pasa.
       vs = diapositivas vistas · cs = conceptos abiertos
       pg = pop-ups abiertos    · vg = videos vistos
       mo = preguntas del juego ya acertadas (guard de §6.53:
            sin esto, reintentar el juego pagaría de nuevo = puntaje
            infinito en una actividad reintentable)
       me = preguntas en las que ya se erró alguna vez (es lo que hace
            que reintentar recupere 10 y no 25)
       mf = el juego se terminó alguna vez (gate de avance) */
  var estado = { vistas: {}, conceptos: {}, popups: {}, videos: {},
                 mjOk: {}, mjErr: {}, mjFin: false, mjAprobado: false };

  function persistir() {
    if (!window.SCORM || !Logros) return;
    SCORM.saveState(Object.assign({
      vs: Object.keys(estado.vistas),
      cs: Object.keys(estado.conceptos),
      pg: Object.keys(estado.popups),
      vg: Object.keys(estado.videos),
      mo: Object.keys(estado.mjOk),
      me: Object.keys(estado.mjErr),
      mf: estado.mjFin ? 1 : 0,
      ma: estado.mjAprobado ? 1 : 0
    }, Logros.serialize()));
  }
  function restaurar() {
    if (!window.SCORM) return;
    var s = SCORM.loadState();
    if (!s) return;
    (s.vs || []).forEach(function (id) { estado.vistas[id] = true; });
    (s.cs || []).forEach(function (id) { estado.conceptos[id] = true; });
    (s.pg || []).forEach(function (id) { estado.popups[id] = true; });
    (s.vg || []).forEach(function (id) { estado.videos[id] = true; });
    (s.mo || []).forEach(function (id) { estado.mjOk[id] = true; });
    (s.me || []).forEach(function (id) { estado.mjErr[id] = true; });
    estado.mjFin = !!s.mf;
    estado.mjAprobado = !!s.ma;
    if (Logros) Logros.restore(sanearLogros(s));
  }

  /* `Logros.restore()` (coto-logros.js) confía en lo que viene del
     `suspend_data` sin cruzarlo contra el catálogo:
       (s.b || []).forEach(function (id) { obtenidos[id] = true; });
     `unlock()` SÍ valida —si el id no está en `BADGES` devuelve false y
     no inventa ninguna tarjeta— así que las dos puertas de entrada al
     mismo conjunto no aplican el mismo criterio. Consecuencia medida:
     con un id viejo guardado, el chip del header muestra "7/6" mientras
     la grilla sigue dibujando 6 tarjetas; el número se pasa del total y
     nada más lo delata.
     De dónde sale un id que ya no existe: de probar builds sucesivos
     sobre la misma carpeta/LMS. `scorm-api.js` deriva su clave de
     respaldo de la ruta del paquete, así que dos versiones del curso
     servidas desde el mismo lugar comparten estado — si entre una y
     otra cambió el catálogo de logros, el id viejo sobrevive.
     Se filtra del lado del curso, que es donde vive el catálogo, en vez
     de parchear el archivo del kit. Relayado (K11). */
  function sanearLogros(s) {
    if (!s) return s;
    var validos = {};
    BADGES.forEach(function (b) { validos[b.id] = true; });
    var limpio = {};
    Object.keys(s).forEach(function (k) { limpio[k] = s[k]; });
    limpio.b = (s.b || []).filter(function (id) { return validos[id]; });
    return limpio;
  }

  function contar(mapa) { return Object.keys(mapa).length; }

  /* ---------- 6 · Arranque ---------- */
  function boot() {
    if (window.SCORM) SCORM.init();

    /* Tracking mínimo del LMS — las dos líneas que exige
       `scorm-tracking.mjs`. Se registran ANTES de `new Motor()` porque
       el constructor emite su primer `slidechange` adentro. */
    document.addEventListener('slidechange', function (e) {
      if (window.SCORM) SCORM.setLocation(e.detail.id);
    });
    document.addEventListener('courseend', function () {
      if (window.SCORM) SCORM.markCompleted();
    });

    window.motor = new Motor(document);

    Logros = initLogros({ badges: BADGES, onChange: persistir });
    restaurar();

    var Player = initPlayer({
      /* `[data-narrate-only]` acota la locución a una parte de la
         diapositiva, igual que ya hace `initPopupNarration()` con los
         pop-ups (coto-ui.js). El kit sostiene esa convención SOLO del
         lado de los pop-ups: `speakSlide` recibe la `<section>` entera y
         no la mira. Lo usa el índice, que muestra el temario en pantalla
         pero no lo enumera en voz alta. Relayado (K9). */
      speakSlide: function (s) {
        var solo = s.querySelector('[data-narrate-only]');
        Narrador.speak(Narrador.textOf(solo || s), 'slide');
      },
      visitedIndexes: function () {
        return motor.slides
          .filter(function (s) { return estado.vistas[s.getAttribute('data-slide')]; })
          .map(function (s) { return parseInt(s.getAttribute('data-slide-index'), 10); });
      }
    });

    /* Cada diapositiva arranca diciendo su título (§7 punto 9.9). Los
       cuerpos de este curso no repiten el título, así que no hay nada
       que recortar. */
    Narrador.setNarrateTitles(true);

    initPopupNarration();
    initPopupStagger();
    initStatPopups();
    initPrefetchNeighbors();
    initSummaryPrint();
    initTiempoActivo();
    initVideoSafetyNet();

    /* ---- iPad: tres parches de plataforma ------------------------
       Los tres son del kit y los tres se arreglan acá porque desde este
       chat no se edita `kit-base/` (§0.1). Van relayados como K19, K20
       y K21. */

    /* (a) El cartel "Parece que estás escribiendo mientras estás en
       pantalla completa". Lo muestra iPadOS cuando una página en
       pantalla completa tiene el foco en un campo de TEXTO. Y el foco
       se lo lleva el propio kit: `Motor.showPopup()` (motor-slides.js
       §929) enfoca el primer elemento enfocable del pop-up, que en el
       glosario es `<input type="search">`. O sea que cada vez que el
       alumno abre el glosario, iPadOS le tira el cartel encima.
       Acá se corrige lo mínimo: SOLO en punteros gruesos (dedo) y SOLO
       si lo que quedó enfocado es un campo de texto, el foco se mueve a
       la tarjeta del pop-up. La tarjeta sigue siendo un destino válido
       para lectores de pantalla (se le pone `tabindex="-1"`), el
       atrapa-foco del motor sigue funcionando, y con teclado —puntero
       fino— no cambia nada: ahí enfocar el buscador es lo correcto. */
    var dedo = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
    if (dedo) {
      document.addEventListener('popupopen', function () {
        var el = document.activeElement;
        if (!el) return;
        var tag = el.tagName;
        var tipo = (el.getAttribute('type') || 'text').toLowerCase();
        var esTexto = tag === 'TEXTAREA' ||
          (tag === 'INPUT' && ['text', 'search', 'email', 'url', 'tel', 'number', 'password'].indexOf(tipo) !== -1);
        if (!esTexto) return;
        var card = el.closest('.modal-card') || el.closest('[data-popup]');
        if (!card) { el.blur(); return; }
        card.setAttribute('tabindex', '-1');
        try { card.focus({ preventScroll: true }); } catch (e) { card.focus(); }
      });
    }

    /* (b) Pantalla completa del video en iOS/iPadOS. El kit ya resuelve
       el bug de fondo —al salir de pantalla completa hay que volver a
       correr `_initShots()`, porque el reproductor vive dentro de una
       captura posicionada en píxeles y `fullscreenchange` no dispara
       ningún resize— pero escucha `fullscreenchange`, que en Safari de
       iOS/iPadOS NO se emite para el fullscreen nativo de un `<video>`:
       ahí los eventos son `webkitbeginfullscreen` / `webkitendfullscreen`.
       Resultado medido por el cliente: después de dar play, el
       reproductor "se tilda" y no se puede agrandar ni achicar.
       Se agregan los dos eventos de WebKit con el mismo tratamiento. */
    Array.prototype.forEach.call(document.querySelectorAll('.d-shot-hit-video, .d-shot-video'), function (v) {
      ['webkitbeginfullscreen', 'webkitendfullscreen'].forEach(function (ev) {
        v.addEventListener(ev, function () {
          /* Dos pasadas: al volver de pantalla completa el layout del
             escenario todavía no se estabilizó en el mismo turno. */
          if (motor && motor._initShots) {
            motor._initShots();
            setTimeout(function () { motor._initShots(); }, 120);
          }
        });
      });
    });

    /* (c) "Al entrar por primera vez a una diapositiva de video no se
       puede dar play; hay que salir y volver". Misma familia que el
       hallazgo K12: `_initShots()` posiciona los `[data-hit]` midiendo
       la captura, y si la imagen todavía no cargó, el botón de play
       queda en el ancla provisional — o sea NO donde el dedo toca. Al
       volver a entrar la imagen ya está en caché, se mide bien y anda.
       Red de seguridad para TODAS las diapositivas, no solo las de
       video: cada captura que todavía no cargó vuelve a disparar el
       posicionamiento cuando termina. */
    Array.prototype.forEach.call(document.querySelectorAll('.d-shot-img'), function (img) {
      if (img.complete && img.naturalWidth > 0) return;
      img.addEventListener('load', function () {
        if (motor && motor._initShots) motor._initShots();
      }, { once: true });
    });

    /* ---- Videos de fondo (portada y unidad 1) ----
       Patrón 1 de coto-media.js. Es la pieza que §7.17 marca como la
       falla más común de este molde: el marcado puesto y el cable no.
       `initBgVideos()` es también quien reintenta MUDO cuando el
       navegador rechaza el autoplay con sonido —lo que pasa SIEMPRE en
       la portada, porque todavía no hubo un gesto del alumno (§7.18
       K10)— y quien muestra el `.d-shot-video-tap`.
       Los dos .mp4 están como placeholder de 0 bytes con su nombre
       final: hasta que el cliente los suba se ve el `poster`, que es la
       misma captura de antes. */
    initBgVideos();

    /* ---- Videos del cuerpo: carátula + el play REAL del kit ----
       Variante (c) de `initInlineCircleVideos` (coto-media.js): el
       `poster` es el recorte del reproductor que dibujó el diseñador
       CON el círculo de play borrado, y encima va el
       `.d-shot-hit-play` del kit — que sí tiene foco, hover y nombre
       accesible, a diferencia de un play horneado (§6.29). */
    initInlineCircleVideos({
      seen: function (src) { return !!estado.videos[src]; },
      markSeen: function (src) { estado.videos[src] = true; },
      onFirstPlay: function (src, title) {
        Logros.award(PTS.video, 'Video: ' + title);
        persistir();
        motor._syncNav();
      }
    });

    /* ---- Los 7 conceptos ----
       ⚠️ Un grupo de N variantes dispara `onChange` N−1 veces, no N: la
       variante 0 es la que ya se ve al entrar (coto-media.js). Acá eso
       es justo lo que queremos — la 0 no es ningún concepto. */
    var swaps = initShotSwap({
      onChange: function (i) {
        var c = CONCEPTOS[i];
        if (!c) return;
        if (!estado.conceptos[c.id]) {
          estado.conceptos[c.id] = true;
          Logros.award(PTS.concepto, c.nom);
          if (contar(estado.conceptos) === 7) Logros.unlock('conceptos');
          persistir();
          motor._syncNav();
        }
        /* La narración de la variante la dispara el curso, no el kit:
           qué se narra es contenido (§5). */
        if (Narrador.isNarrating()) Narrador.speak(c.txt, 'other');
      }
    });

    /* ---- Gates de contenido ----
       · `initPopupGate` lee `data-require-popups` (las 4 fichas).
       · `initVideoGate` SONDEA cada `data-require-seen`: con los .mp4
         todavía en placeholder los exime solos, así el curso nunca
         queda trabado, y el gate vuelve a valer el día que el cliente
         suba los archivos, sin tocar código. */
    var popupGate = initPopupGate({
      seen: function (id) { return !!estado.popups[id]; },
      markSeen: function (id) { estado.popups[id] = true; },
      onChange: function (id) { premiarFicha(id); }
    });
    var videoGate = initVideoGate({
      seen: function (src) { return !!estado.videos[src]; },
      markSeen: function (src) { estado.videos[src] = true; }
    });

    function premiarFicha(id) {
      if (FICHAS.indexOf(id) === -1) return;
      Logros.award(PTS.ficha, 'Ficha de repaso');
      if (FICHAS.every(function (f) { return !!estado.popups[f]; })) Logros.unlock('repaso');
      persistir();
      motor._syncNav();
    }

    /* Gate propio de este curso: los 7 conceptos y el mini juego
       terminado. El motor solo consulta `canAdvance`, no sabe por qué. */
    function faltanConceptos(slideEl) {
      if (!slideEl || slideEl.getAttribute('data-slide') !== 'conceptos') return [];
      return CONCEPTOS.slice(1)
        .filter(function (c) { return !estado.conceptos[c.id]; })
        .map(function (c) { return c.id; });
    }
    function faltaJuego(slideEl) {
      if (!slideEl || slideEl.getAttribute('data-slide') !== 'minijuego') return [];
      /* Se pide APROBAR, no solo terminar (pedido del cliente). Antes
         alcanzaba con `estado.mjFin`, que se pone igual al perder: se
         podía seguir el curso sin haber acertado una sola. Ahora el
         gate mira `mjAprobado`, que se persiste y solo se pone cuando
         el juego termina con al menos `MJ_APROBACION` aciertos.
         Reintentar es ilimitado y el umbral es 3 de 5, así que nadie
         queda encerrado; y una vez aprobado queda aprobado, aunque
         después vuelva a jugar y le vaya peor. */
      return estado.mjAprobado ? [] : ['minijuego'];
    }

    motor.canAdvance = function (slideEl) {
      return popupGate.faltan(slideEl).length === 0 &&
             videoGate.faltan(slideEl).length === 0 &&
             faltanConceptos(slideEl).length === 0 &&
             faltaJuego(slideEl).length === 0;
    };

    /* Sin esto el gate es mudo: el alumno ve que "Siguiente" no anda y
       no sabe QUÉ le falta. `pendientes` es la vía para los gates
       propios; los declarativos van en `gates`. */
    initGateHints({
      pendientes: function (slideEl) {
        var out = [];
        faltanConceptos(slideEl).forEach(function (id) {
          var i = CONCEPTOS.findIndex(function (c) { return c && c.id === id; });
          var el = slideEl.querySelector('[data-shot-swap-go="' + i + '"]');
          if (el) out.push({ el: el, tipo: out.length ? 'conceptos' : 'concepto' });
        });
        if (faltaJuego(slideEl).length) {
          var btn = slideEl.querySelector('[data-panel]:not([hidden]) [data-hit]');
          out.push({ el: btn, tipo: 'terminar el mini juego' });
        }
        return out;
      },
      gates: [
        { gate: popupGate,
          sel: function (id) { return '[data-popup-trigger="' + id + '"]'; },
          uno: 'ficha', varias: 'fichas' },
        { gate: videoGate,
          sel: function (src) { return '[data-inline-video][data-video="' + src + '"]'; },
          uno: 'video', varias: 'videos' }
      ]
    });

    /* ---- Índice lateral y glosario ----
       Los DOS devuelven un `refresh` y hay que guardarlo: corren una
       vez al crearse y después no se enteran de nada (§7.18 K5). */
    var refrescarIndice = initIndexJumps({
      visited: function (id) { return !!estado.vistas[id]; }
    });
    initGlossarySearch();
    var refrescarGlosario = initGlossaryUnlock({
      seen: function (id) { return !!estado.vistas[id]; },
      onUnlock: function (labels) {
        Player.toast('🔓 ' + (labels.length === 1
          ? 'Desbloqueaste “' + labels[0] + '”'
          : 'Desbloqueaste ' + labels.length + ' términos') + ' del glosario');
      }
    });

    /* ---- Mini juego ---- */
    var MJ_UI = initMinijuego();

    /* ---- Cierre ----
       Se desbloquea al ENTRAR (más abajo, en `slidechange`): el gate del
       mini juego ya garantiza que nadie llega antes de terminarlo, así
       que una pantalla "bloqueada" que nunca se ve sería justo el
       elemento muerto que §7.3 punto 4 prohíbe dejar. */
    var Cierre = initCierreCelebration({
      statIds: ['d-cert-points', 'd-cert-badges', 'd-cert-mj', 'd-cert-time'],
      ctaLabel: 'Ver mi resumen',
      salirLabel: 'Salir del curso',
      onUnlock: function () {
        setText('d-cert-points', String(Logros.puntos()));
        setText('d-cert-badges', String(Logros.obtenidos()));
        setText('d-cert-mj', contar(estado.mjOk) + '/5');
        setText('d-cert-time', String(Math.max(1, Math.round((window.tiempoActivoMs ? tiempoActivoMs() : 0) / 60000))));
      },
      onFinish: function () {
        Logros.unlock('curso');
        /* Los contadores finales se recalculan DESPUÉS de otorgar el
           último logro, nunca en el mismo paso (bug real del kit, README
           punto 11): si no, el resumen muestra "5/6 logros" en la misma
           pantalla que entrega el sexto. */
        setText('d-cert-points', String(Logros.puntos()));
        setText('d-cert-badges', String(Logros.obtenidos()));
        pintarMedalla(Logros.puntos(), NIVELES);
        corregirSubMedalla(Logros.puntos());
        if (window.XAPI) XAPI.completed(COURSE_SLUG, COURSE_NAME);
        if (window.SCORM) SCORM.markCompleted();
        persistir();
      },
      onCelebrate: function () { if (window.CotoUI && CotoUI.sWin) CotoUI.sWin(); },
      stagger: function (el) { if (window.staggerReveal) staggerReveal(null, el); }
    });

    /* ---- Marcar visitas, refrescar índice/glosario, desbloquear el
            cierre. Un solo listener, después de todo lo anterior. ---- */
    document.addEventListener('slidechange', function (e) {
      estado.vistas[e.detail.id] = true;
      if (refrescarIndice) refrescarIndice();
      if (refrescarGlosario) refrescarGlosario();
      if (e.detail.id === 'cierre') Cierre.unlockCierre();
      if (e.detail.id === 'minijuego') MJ_UI.alEntrar();
      /* "Algunos conceptos importantes" vuelve SIEMPRE a su estado
         inicial al reentrar (pedido explícito del cliente): la
         ilustración del librito con la lupa y ninguna píldora marcada.
         `go(0, true)` es silencioso a propósito — `silencioso` corta el
         `onChange`, así que el reset no vuelve a pagar puntos ni a
         narrar; y `estado.conceptos` NO se toca, que es lo que sostiene
         el gate de la diapositiva y el logro "Explorador" (si se
         limpiara, quien ya abrió los 7 quedaría trabado de nuevo). */
      if (e.detail.id === 'conceptos' && swaps.conceptos) swaps.conceptos.go(0, true);
      persistir();
    });

    /* Techo de "hasta dónde llegó" para la barra arrastrable: se
       calcula desde el estado YA RESTAURADO, no desde `motor.index` en
       frío — si no, quien reabre el curso en una sesión nueva se
       encuentra la barra creyendo que no vio nada (§6.51). */
    /* Los "desde N" de la tablita de medallas se escriben DESDE
       `NIVELES`, no a mano en el marcado. El generador del kit deja ahí
       los números de ejemplo (148/190/230) y este curso derivó los
       suyos de un recorrido instrumentado (74/127/180, ver
       README-CURSO.md): quedaron los del ejemplo, así que el alumno leía
       un umbral y el contador usaba otro. Es exactamente la trampa de
       §7.3 punto 19 —"la tabla es una intención, el contador es el
       hecho"— pero al revés: acá la tabla mentía en pantalla. Pintarla
       desde la misma constante que decide la medalla hace imposible que
       vuelvan a separarse. */
    NIVELES.forEach(function (n) {
      var li = document.querySelector('[data-rango="' + n.id + '"] i');
      if (li) li.textContent = 'desde ' + n.desde;
    });

    motor.restoreMaxVisited(estado.vistas);
    if (refrescarIndice) refrescarIndice();
    if (refrescarGlosario) refrescarGlosario();

    /* Lo expone para el recorrido instrumentado de
       `tools/tests/puntaje-curso.mjs`, que es quien verifica que el
       máximo real coincida con el que sostienen los umbrales. */
    window.__CURSO__ = {
      maxSinVideos: MAX_SIN_VIDEOS, pisoGate: PISO_GATE,
      niveles: NIVELES, pts: PTS, mj: MJ_UI
    };

    if (window.SCORM) SCORM.commit();
  }

  /* El kit escribe debajo de la medalla "N puntos · el máximo posible
     del curso" cada vez que no hay un nivel más arriba (coto-cierre.js
     §363), o sea para CUALQUIER puntaje por encima del oro. El cliente
     lo vio con 189 sobre un máximo de 199: la pantalla le decía que
     había sacado el máximo y no era cierto.
     Acá se corrige sin tocar el kit y sin inventar: si el puntaje es
     menor que el máximo real del curso, se dice lo que sí es verdad
     —que ya tiene la medalla más alta— y se aclara cuál era el techo.
     Se relaya como K17. */
  function corregirSubMedalla(puntos) {
    var sub = document.querySelector('[data-medalla-sub]');
    if (!sub || puntos >= MAX_SIN_VIDEOS) return;
    var tope = NIVELES.reduce(function (a, n) { return n.desde > a.desde ? n : a; }, NIVELES[0]);
    if (puntos < tope.desde) return;         // el kit ya dice "te faltan N para…"
    sub.textContent = puntos + ' puntos · ya tenés la medalla más alta (el máximo del curso es ' +
      MAX_SIN_VIDEOS + ')';
  }

  function setText(id, txt) {
    var el = document.getElementById(id);
    if (el) el.textContent = txt;
  }

  /* ============================================================
     MINI JUEGO — 5 conceptos, 3 vidas, puntaje propio.
     La cáscara visual es del kit (`coto-minijuego.css`); esto es la
     lógica, que es contenido de este curso. Las 3 pantallas del PDF
     son capas `[data-panel]` de la misma diapositiva.
     ============================================================ */
  function initMinijuego() {
    var raiz = document.querySelector('[data-slide="minijuego"]');
    if (!raiz) return { alEntrar: function () {} };

    var elEscena = raiz.querySelector('[data-mj-escena]');
    var elConsigna = raiz.querySelector('[data-mj-consigna]');
    var elOpciones = raiz.querySelector('[data-mj-opciones]');
    var elFb = raiz.querySelector('[data-mj-fb]');
    var zonaFb = raiz.querySelector('[data-mj-zona]') || elFb.parentNode;
    var elMolde = raiz.querySelector('[data-mj-molde]');
    /* La coletilla del error vive en una constante porque se usa DOS
       veces: al medir el fantasma (para reservar el alto exacto) y al
       mostrar la devolución de verdad. Escrita dos veces, el fantasma
       reservaría un alto distinto del real en cuanto alguien la
       retocara en un solo lado. */
    var COLA_ERROR = 'Podés probar otra opción o seguir al siguiente concepto.';
    var elN = raiz.querySelector('[data-mj-n]');
    var elPts = raiz.querySelector('[data-mj-pts]');
    var elVidas = raiz.querySelector('[data-mj-vidas]');

    var i = 0, vidas = MJ_VIDAS, puntos = MJ_INICIAL, aciertos = 0, bloqueado = false;

    /* Corazones "pixel art", no el glifo ❤: el arte del PDF los dibuja
       de 8 bits y `coto-minijuego.css` ya estila `.d-mj-heart`. */
    function pintarVidas() {
      if (!elVidas) return;
      elVidas.innerHTML = '';
      for (var v = 0; v < MJ_VIDAS; v++) {
        var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        s.setAttribute('class', 'd-mj-heart' + (v < vidas ? '' : ' is-off'));
        s.setAttribute('viewBox', '0 0 16 14');
        s.setAttribute('aria-hidden', 'true');
        var p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        p.setAttribute('fill', 'currentColor');
        p.setAttribute('d', 'M2 1h4v1h1v1h2V2h1V1h4v1h1v5h-1v2h-1v1h-1v1h-1v1h-1v1h-1v1H7v-1H6v-1H5v-1H4v-1H3V9H2V7H1V2h1z');
        s.appendChild(p);
        elVidas.appendChild(s);
      }
      elVidas.setAttribute('aria-label', vidas + ' de ' + MJ_VIDAS + ' vidas');
    }

    function hud() {
      if (elN) elN.textContent = String(Math.min(i + 1, MJ.length));
      if (elPts) elPts.textContent = String(puntos);
      pintarVidas();
    }

    function panel(id) {
      var trig = raiz.querySelector('[data-target="' + id + '"]');
      if (trig) { trig.click(); recolocarOverlays(); return; }
      /* Sin disparador en el marcado (las pantallas finales no lo
         tienen: se llega por lógica, no por un clic), se mueve a mano
         el mismo juego de capas que maneja el motor. */
      raiz.querySelectorAll('[data-panel]').forEach(function (p) {
        p.hidden = p.getAttribute('data-panel') !== id;
      });
      document.dispatchEvent(new CustomEvent('layerchange', {
        bubbles: true, detail: { target: id }
      }));
      recolocarOverlays();
    }

    /* `_initShots()` escribe left/top/width/height EN PÍXELES sobre cada
       `[data-hit]`/`[data-place]`, y para uno que vive dentro de un
       `[data-panel][hidden]` no puede calcular nada: la imagen mide 0.
       El motor lo reintenta cuando el elemento se vuelve visible, pero
       vía `ResizeObserver` — o sea, un frame DESPUÉS. En ese hueco los
       dos números del panel final del mini juego se pintan en (0,0), en
       la esquina, y recién después saltan a su lugar.
       Lo agarró `overlays-colocados` de la suite, y de forma
       intermitente: 1 de cada 3 corridas los medía en (0, 788). Un
       `slidechange` sí dispara el recálculo; un `layerchange` no —
       así que le toca al curso pedirlo. Relayado (K12). */
    function recolocarOverlays() {
      if (!window.motor || !motor._initShots) return;
      motor._initShots();
    }

    /* Los dos números del panel final viven en un `[data-panel][hidden]`,
       y un `[data-shot]` oculto mide 0x0: `_initShots()` no puede
       calcular nada, así que el motor les pone su ANCLA PROVISIONAL
       (`left:0; top:0`, kit-base v1.9.72 §7.18 K2) hasta que se revelan.
       Eso deja dos efectos:
         · para el alumno, un frame con los números en la esquina del
           arte la primera vez que se abre el panel;
         · para `overlays-colocados` de la suite, un fallo INTERMITENTE
           —1 de cada 3 corridas— midiéndolos en (0, 788), porque el
           test revela la capa y mide en el mismo turno, sin que el
           ResizeObserver llegue a correr.
       Se resuelve posicionándolos UNA vez al arranque: se revelan, se
       mide y se vuelven a ocultar, todo en el mismo turno (el navegador
       no pinta en el medio, así que no se ve nada). A partir de ahí
       tienen coordenadas reales y el ancla no vuelve a aplicar.
       Por eso, además, esos dos `.d-shot-img` NO llevan `loading="lazy"`
       (a diferencia del resto, §3 punto 13): una imagen lazy dentro de
       un panel oculto no se descarga nunca, y sin `naturalWidth` no hay
       nada que medir. Son 145 KB que se adelantan a propósito.
       Relayado (K12). */
    function preposicionarPanelesOcultos() {
      if (!window.motor || !motor._initShots) return;
      var ocultos = [];
      raiz.querySelectorAll('[data-panel][hidden]').forEach(function (pan) {
        if (!pan.querySelector('[data-shot] [data-hit], [data-shot] [data-place]')) return;
        ocultos.push(pan);
        pan.hidden = false;
      });
      if (!ocultos.length) return;
      motor._initShots();
      ocultos.forEach(function (pan) { pan.hidden = true; });
    }
    /* Hay que esperar a que las imágenes tengan `naturalWidth`: sin eso
       `place()` sale por su guard y la medición no ocurre. */
    function cuandoCarguenLasImagenes(fn) {
      var imgs = Array.prototype.slice.call(
        raiz.querySelectorAll('[data-panel] .d-shot-img'));
      var faltan = imgs.filter(function (im) { return !im.complete || !im.naturalWidth; });
      if (!faltan.length) { fn(); return; }
      var pendientes = faltan.length;
      faltan.forEach(function (im) {
        function listo() { if (--pendientes === 0) fn(); }
        im.addEventListener('load', listo, { once: true });
        im.addEventListener('error', listo, { once: true });
      });
    }

    function render() {
      var q = MJ[i];
      bloqueado = false;
      if (elEscena) elEscena.setAttribute('src', q.escena);
      if (elConsigna) elConsigna.textContent = q.consigna;
      /* Reserva de espacio (pedido del cliente: "el espacio para la
         retroalimentación ya tiene que estar reservado desde el
         principio, aunque esté vacío"). No se reserva un alto fijo a
         ojo: se escribe el texto REAL más largo de los dos que puede
         mostrar esta pregunta y se lo deja invisible. Así el cartel
         ocupa exactamente lo que va a ocupar —ni un píxel de más, ni
         de menos— en cada pregunta, sin una constante que se
         desactualice cuando cambie un texto. */
      if (elMolde) {
        elMolde.textContent = (q.mal + ' ' + COLA_ERROR).length > q.why.length
          ? q.mal + ' ' + COLA_ERROR : q.why;
      }
      if (elFb) { elFb.textContent = ''; elFb.className = 'd-mj-fb'; }
      fantasmaDeBoton(q);
      if (elOpciones) {
        elOpciones.innerHTML = '';
        q.opts.forEach(function (txt, k) {
          var b = document.createElement('button');
          b.type = 'button';
          b.className = 'd-mj-opt';
          b.textContent = txt;
          b.addEventListener('click', function () { responder(k, b); });
          elOpciones.appendChild(b);
        });
      }
      hud();
      ajustarEscena();
      /* El motor no se entera de un `innerHTML`: si esta función no
         narrara, el juego quedaría mudo a partir del primer concepto
         (CLAUDE.md §1). El guard de `hidden` evita narrar en el render
         inicial, con la capa todavía oculta. */
      var capa = elOpciones && elOpciones.closest('[data-panel]');
      if (capa && !capa.hidden && !raiz.hidden) {
        narrar(q.consigna + ' ' + q.opts.join('. '));
      }
    }

    /* TODA la voz del juego pasa por acá, y por un motivo concreto:
       `Narrador.speak()` arranca llamando a `cancel()` (narrador.js),
       así que enrutar cada cambio de estado por esta función garantiza
       que lo anterior se corte antes de que empiece lo siguiente. Es el
       mismo "¿quién lo apaga?" de §6.10.1 punto 1, aplicado a la voz:
       el motor corta la locución al cambiar de DIAPOSITIVA y al cerrar
       un POP-UP, pero un `layerchange` —que es lo que pasa acá— no corta
       nada, así que le toca al curso. */
    function narrar(txt) {
      if (!txt || !window.Narrador) return;
      Narrador.speak(txt, 'other');
    }
    function textoDePanel(id) {
      var p = raiz.querySelector('[data-panel="' + id + '"] .sr-only');
      return p ? p.textContent.trim() : '';
    }

    function feedback(ok, txt) {
      if (!elFb) return;
      elFb.className = 'd-mj-fb ' + (ok ? 'is-ok' : 'is-bad');   // saca `is-fantasma`
      /* Tras un error el cartel dice las DOS salidas que hay. Sin esa
         línea, el alumno ve la explicación y nada más: las opciones que
         quedan vivas no se leen como "probá otra", y el botón nuevo
         podría leerse como la única salida. */
      elFb.textContent = ok ? txt : txt + ' ' + COLA_ERROR;
    }

    function responder(k, btn) {
      if (bloqueado) return;
      var q = MJ[i];
      if (k === q.ok) {
        bloqueado = true;
        btn.classList.add('is-ok');
        elOpciones.querySelectorAll('.d-mj-opt').forEach(function (b) { b.disabled = true; });
        puntos += MJ_ACIERTO;
        aciertos++;
        if (window.CotoUI && CotoUI.sCorrect) CotoUI.sCorrect();
        /* Guard persistido (§6.53): una pregunta paga UNA sola vez en
           todo el curso. Sin esto, reintentar el juego sería puntaje
           infinito. Y paga menos si ya se había errado esa pregunta:
           lo que se premia es la precisión, no la insistencia (§7.14). */
        if (!estado.mjOk[q.id]) {
          estado.mjOk[q.id] = true;
          Logros.award(estado.mjErr[q.id] ? PTS.mjBienTrasError : PTS.mjBien,
                       'Concepto ' + (i + 1) + ' de 5');
        }
        feedback(true, q.why);
        /* Corta la consigna si todavía estaba sonando y arranca la
           devolución. Antes no se narraba ninguna de las dos cosas: la
           consigna seguía de fondo y la devolución no se escuchaba. */
        narrar(q.why);
        hud();
        siguientePaso(true);
        persistir();
      } else {
        btn.classList.add('is-bad');
        btn.disabled = true;
        vidas--;
        puntos = Math.max(0, puntos - MJ_ERROR);
        estado.mjErr[q.id] = true;
        if (window.CotoUI && CotoUI.sWrong) CotoUI.sWrong();
        feedback(false, q.mal);
        hud();
        persistir();
        /* Tras un error el juego NO avanza solo: las opciones que quedan
           siguen vivas para volver a intentar. Pero sin un botón, la
           única diferencia visible contra el flujo de acierto era la
           AUSENCIA de salida — y eso se lee como "quedé trabado"
           (reportado por el cliente). Ahora la salida está siempre. */
        if (vidas > 0) siguientePaso(false);
        /* Si este error fue el último, la devolución y el resultado se
           narran JUNTOS, en una sola emisión: narrar el "por qué" y
           enseguida pisarlo con la pantalla final dejaría al alumno sin
           la explicación justo cuando más la necesita. */
        /* Quedarse sin vidas tampoco reprueba por sí solo: si ya llegó a
           los 3 aciertos, el juego está aprobado igual. */
        if (vidas <= 0) terminar(aprobo(), q.mal);
        else narrar(q.mal);
      }
    }

    /* `acerto` decide el rótulo, el estilo y el foco — NO si el botón
       existe: existe siempre. Si el alumno erró y después acierta, esta
       función corre de nuevo, de ahí el `remove()` del botón anterior
       para no terminar con dos. */
    /* El botón de avance también reserva su lugar desde el render: se
       dibuja con el rótulo que va a tener y se lo deja invisible
       (`.d-mj-next-fantasma`, sin la clase `.d-mj-next`). La clase
       final la pone `siguientePaso()`, así que `_auto()` y la suite —que
       buscan `.d-mj-next`— nunca encuentran el fantasma y no clickean
       un botón que el alumno no ve. */
    function fantasmaDeBoton(q) {
      var previo = zonaFb.querySelector('button');
      if (previo) previo.remove();
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'd-mj-next-fantasma btn btn-cat';
      b.textContent = rotulo(true);
      b.tabIndex = -1;
      b.setAttribute('aria-hidden', 'true');
      zonaFb.appendChild(b);
      return b;
    }
    function rotulo(acerto) {
      if (i + 1 >= MJ.length) return 'Ver resultado';
      return acerto ? 'Siguiente concepto' : 'Seguir al siguiente';
    }

    function siguientePaso(acerto) {
      var previo = zonaFb.querySelector('button');
      if (previo) previo.remove();
      var ultima = i + 1 >= MJ.length;
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'd-mj-next btn ' + (acerto ? 'btn-cat' : 'btn-cat-ghost');
      b.textContent = rotulo(acerto);
      b.addEventListener('click', function () {
        b.remove();
        if (!ultima) { i++; render(); }
        else terminar(aprobo());
      });
      zonaFb.appendChild(b);
      /* El foco se mueve solo si la pregunta quedó cerrada. Con un error
         todavía hay opciones vivas: llevarle el foco al botón de seguir
         empuja a saltear justo cuando conviene reintentar. */
      if (acerto) b.focus();
    }
    /* Aprobar es acertar al menos `MJ_APROBACION` de los 5 conceptos
       (pedido del cliente: con 3 de 5 ya aprueba).
       Antes era "haber acertado la ÚLTIMA pregunta", que venía de otro
       pedido —desde que se puede saltear, llegar al final no prueba
       nada— pero dejaba afuera a quien acertaba 4 y fallaba la última.
       Se cuenta sobre `aciertos`, que es lo acertado EN ESTA vuelta:
       `estado.mjOk` persiste entre partidas y usarlo haría que un
       segundo intento arranque con crédito del primero. */
    function aprobo() { return aciertos >= MJ_APROBACION; }

    function terminar(gano, preludio) {
      estado.mjFin = true;
      /* Nunca se baja: si ya aprobó una vez, el gate queda abierto. */
      if (gano) estado.mjAprobado = true;
      Logros.unlock('juego');
      if (gano && aciertos === MJ.length && !Object.keys(estado.mjErr).length) {
        Logros.unlock('preciso');
      }
      var suf = gano ? 'ok' : 'retry';
      setTextoNodo('[data-mj-' + suf + '-aciertos]', aciertos + '/' + MJ.length);
      setTextoNodo('[data-mj-' + suf + '-puntos]', String(puntos));
      panel('mj-fin-' + suf);
      narrar([preludio, textoDePanel('mj-fin-' + suf)].filter(Boolean).join(' '));
      persistir();
      motor._syncNav();
    }

    function setTextoNodo(sel, txt) {
      var el = raiz.querySelector(sel);
      if (el) el.textContent = txt;
    }

    function reiniciar() {
      i = 0; vidas = MJ_VIDAS; puntos = MJ_INICIAL; aciertos = 0;
      panel('mj-juego');
      render();
    }

    /* El botón "¡Empecemos!" ya cambia de capa solo (`data-target`, lo
       cablea el motor); lo único que falta es pintar la 1ª pregunta. */
    document.addEventListener('layerchange', function (e) {
      if (e.detail && e.detail.target === 'mj-juego' && !elOpciones.children.length) render();
    });

    var btnContinuar = raiz.querySelector('[data-mj-continuar]');
    if (btnContinuar) btnContinuar.addEventListener('click', function () {
      /* Guard de panel oculto: el recorrido instrumentado de la suite
         clickea TODOS los `[data-hit]` de cada diapositiva, incluidos
         los de capas escondidas. Sin esto, un clic sobre un botón que
         el alumno no puede ver navegaría igual. */
      if (btnContinuar.closest('[data-panel]').hidden) return;
      motor._advance(1);
    });
    var btnReintentar = raiz.querySelector('[data-mj-reintentar]');
    if (btnReintentar) btnReintentar.addEventListener('click', function () {
      if (btnReintentar.closest('[data-panel]').hidden) return;
      reiniciar();
    });
    /* "Volver a jugar" en la pantalla de ÉXITO (pedido del cliente:
       "aunque ya aprobé el juego, quiero poder volver a jugarlo").
       Rejugar es seguro por construcción y conviene decir por qué, que
       es justo lo que §6.53 advierte: los puntos de cada concepto los
       guarda `estado.mjOk`, persistido en `suspend_data`, así que una
       segunda vuelta no paga de nuevo; `estado.mjErr` también persiste,
       así que tampoco se puede "limpiar el prontuario" para arrancar el
       logro `preciso`; y `estado.mjAprobado` nunca se baja, así que el
       gate de la diapositiva no vuelve a cerrarse mientras se rejuega. */
    var btnRejugar = raiz.querySelector('[data-mj-rejugar]');
    if (btnRejugar) btnRejugar.addEventListener('click', function () {
      if (btnRejugar.closest('[data-panel]').hidden) return;
      reiniciar();
    });

    /* ---- Alto real de la escena (reporte del cliente: "el mini juego
       se ve apretado en pantallas chicas") ----
       El ancho compartido de las tres filas está topeado por el alto que
       le sobra a la ilustración, y ese alto no se puede escribir en CSS:
       depende de cuánto miden la fila de estado, las opciones y la zona
       de devolución, que son contenido. Peor: la fila de estado ENVUELVE
       cuando el ancho se achica, así que una constante en `cqh` se muerde
       la cola —bajarla hace envolver la fila, que se come el alto recién
       liberado— y esa es exactamente la forma que tenía el bug.
       Acá se mide y se publica como `--mj-alto-escena`; el CSS lo usa
       como segundo tope de `--mj-ancho`.

       Dos pasadas a propósito: la primera cambia el ancho, eso puede
       hacer que la fila de estado deje de envolver (o empiece), y la
       segunda mide ya con el layout nuevo. Converge ahí — se verificó
       midiendo los huecos en 6 tamaños. */
    var AIRE = 10;               // respiro mínimo entre filas, en px
    function ajustarEscena() {
      var play = raiz.querySelector('.d-mj-play');
      if (!play) return;
      var capa = play.closest('[data-panel]');
      if (!capa || capa.hidden || raiz.hidden) return;
      var top = play.querySelector('.d-mj-top');
      var body = play.querySelector('.d-mj-body');
      var grid = play.querySelector('.d-mj-grid');
      var zona = play.querySelector('.d-mj-zona-fb');
      if (!top || !body || !grid || !zona) return;
      /* Una sola pasada alcanza desde que la fila de estado, las
         opciones y la zona de devolución NO siguen el ancho de la
         escena (ver el comentario en diapositivas.css): sus altos ya no
         dependen de lo que esta medición decida, así que no hay
         realimentación que iterar. */
      {
        var cs = getComputedStyle(play);
        var gapPlay = parseFloat(cs.rowGap) || 0;
        var gapBody = parseFloat(getComputedStyle(body).rowGap) || 0;
        var libre = play.clientHeight
          - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom)
          - top.offsetHeight - grid.offsetHeight - zona.offsetHeight
          - gapPlay * 2 - gapBody - AIRE;
        /* Piso de 90px: por debajo de eso la ilustración ya no se lee y
           conviene que sobresalga un poco antes que desaparecer. */
        play.style.setProperty('--mj-alto-escena', Math.max(90, Math.round(libre)) + 'px');
      }
    }
    /* `ResizeObserver` y no `resize`: el escenario también cambia de alto
       cuando se abre el teclado en un teléfono o cuando el navegador
       esconde su barra, y eso no emite `resize` en todos lados. */
    if (window.ResizeObserver) {
      var ro = new ResizeObserver(function () { ajustarEscena(); });
      var elPlay = raiz.querySelector('.d-mj-play');
      if (elPlay) ro.observe(elPlay);
    }
    document.addEventListener('layerchange', function (e) {
      if (e.detail && e.detail.target === 'mj-juego') ajustarEscena();
    });

    pintarVidas();
    cuandoCarguenLasImagenes(preposicionarPanelesOcultos);
    cuandoCarguenLasImagenes(ajustarEscena);

    return {
      alEntrar: function () { hud(); },
      /* Para el recorrido instrumentado de `tools/tests/puntaje-curso.mjs`:
         juega solo, sin mouse. Tres modos, uno por cada cosa que hay
         que poder medir sobre el puntaje:
           'perfecto'   → los 5 a la primera (el MÁXIMO real);
           'pesimo'     → siempre mal hasta quedarse sin vidas (el PISO
                          que el gate garantiza: terminar el juego sin
                          acertar nada);
           'insistente' → yerra cada pregunta una vez y recién después
                          la acierta, reintentando cuantas veces haga
                          falta — es el alumno de §7.14, el que "se
                          equivocó bastante y llegó igual al máximo";
           'minimo'     → lo más barato que el gate acepta: aprueba con
                          3 de 5 y cada una de esas 3 tras haber errado,
                          o sea 10 puntos por pregunta en vez de 25. De
                          acá sale el PISO del gate desde que avanzar
                          exige aprobar. */
      /* Para los tests: qué opción es la correcta en cada pregunta. Lo
         necesita el chequeo del umbral de aprobación (3 de 5), que
         tiene que acertar exactamente 3 y fallar 2 — algo que `_auto()`
         no cubre porque sus tres modos son "todas bien", "todas mal" y
         "todas bien tras errar". Es solo lectura y no toca el estado. */
      _claves: function () { return MJ.map(function (q) { return q.ok; }); },
      _aprobacion: MJ_APROBACION,
      /* Arranca una partida limpia desde donde sea que esté el juego
         (intro, a mitad, o en una pantalla final). Lo necesita el test
         del umbral, que corre después de otros que ya jugaron: sin un
         reinicio explícito arrancaba a mitad de una partida ajena y las
         respuestas quedaban corridas una pregunta. Es el mismo
         `reiniciar()` que usan "Reintentar" y "Volver a jugar". */
      _reiniciar: function () { reiniciar(); },
      _auto: function (modo) {
        modo = modo || 'perfecto';
        function finAbierto() {
          return !!raiz.querySelector('[data-panel="mj-fin-ok"]:not([hidden]), [data-panel="mj-fin-retry"]:not([hidden])');
        }
        panel('mj-juego');
        if (!elOpciones.children.length) render();
        for (var guard = 0; guard < 200; guard++) {
          if (finAbierto()) {
            if (modo === 'pesimo') break;
            var reint = raiz.querySelector('[data-mj-reintentar]');
            if (reint && !reint.closest('[data-panel]').hidden) { reint.click(); continue; }
            break;                       // terminó bien: no hay nada más que jugar
          }
          var q = MJ[i];
          /* Elegir "la equivocada" como `(ok+1) % n` a secas no sirve:
             una opción errada queda `disabled`, así que en la segunda
             vuelta ese índice ya no está y cualquier fallback termina
             tocando la CORRECTA — el recorrido "pésimo" acertaba sin
             querer y el piso medido daba 10 puntos de más. Se pide
             siempre la primera opción viva que NO sea la correcta. */
          var erroneaViva = null;
          for (var n = 0; n < elOpciones.children.length; n++) {
            if (n !== q.ok && !elOpciones.children[n].disabled) {
              erroneaViva = elOpciones.children[n]; break;
            }
          }
          var btn;
          if (modo === 'perfecto') btn = elOpciones.children[q.ok];
          else if (modo === 'pesimo') btn = erroneaViva;
          else if (modo === 'minimo') {
            /* Lo MÁS BARATO que el gate acepta desde que hay que
               aprobar: errar una vez cada una de las 3 primeras y recién
               ahí acertarlas (10 en vez de 25), y las 2 últimas errarlas
               y seguir de largo. Con eso el juego queda aprobado (3 de
               5) pagando lo mínimo posible. Es el recorrido del que sale
               el piso del gate, y por lo tanto el bronce. */
            btn = (i < MJ_APROBACION && estado.mjErr[q.id])
              ? elOpciones.children[q.ok] : erroneaViva;
          }
          else btn = estado.mjErr[q.id] ? elOpciones.children[q.ok] : erroneaViva;
          if (!btn || btn.disabled) break;
          /* Desde que el botón de avance también aparece al ERRAR, hay
             que mirar QUÉ se tocó antes de tocarlo: clickearlo siempre
             haría que 'insistente' saltee la pregunta en vez de
             corregirla, y que 'pesimo' vaya pasando de pregunta en vez
             de agotar las vidas. Solo se avanza después de un acierto —
             que es, además, lo que hace un alumno que está jugando. */
          var eraCorrecta = (btn === elOpciones.children[q.ok]);
          btn.click();
          /* En 'minimo' hay que avanzar TAMBIÉN tras errar las dos
             últimas: si no, se queda reintentándolas y nunca llega al
             final. En los otros modos avanzar tras un error cambiaría
             lo que cada uno mide (ver el comentario de abajo). */
          if (eraCorrecta || (modo === 'minimo' && i >= MJ_APROBACION)) {
            var next = raiz.querySelector('.d-mj-next');
            if (next) next.click();
          }
        }
        return { aciertos: aciertos, puntos: puntos, vidas: vidas, fin: finAbierto() };
      }
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
